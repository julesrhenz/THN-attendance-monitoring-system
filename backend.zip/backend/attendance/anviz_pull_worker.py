"""
anviz_pull_worker.py
---------------------
Standalone worker invoked by sync_bio.py's _pull_anviz_logs() as a child
process (see that function's docstring for why: DLL multi-instance safety,
plus the ability to hard-kill a hung connection without taking down the
whole scheduler process).

Usage:
    python anviz_pull_worker.py <ip_address> <port> [dll_path]

On success, prints a single JSON array to stdout:
    [{"user_id": 16928, "timestamp": "2025-07-15T19:04:24", "punch": 1}, ...]
-- this is exactly the shape _pull_anviz_logs() already expects
   (json.loads(stdout), then datetime.fromisoformat(r["timestamp"])).

Everything else (progress markers, warnings, tracebacks) goes to stderr.
_pull_anviz_logs() deliberately keeps stderr around on a timeout/kill so
these markers show up in the failure log -- that's how you tell "never
even got past login" apart from "hung mid-download".

-----------------------------------------------------------------------
PUNCH MAPPING -- READ THIS BEFORE TRUSTING IT IN PRODUCTION:

AttendanceRecord.record_type from the real Anviz DLL (via anviz_ep300.py)
is passed straight through as `punch`, matching the zk library's own
convention (0=check-in, 1=check-out, 2=break-out, 3=break-in, 4=OT-in,
5=OT-out). The one confirmed real sample so far came back as record_type=1
(a clean small int), which is consistent with a direct passthrough.

What I have NOT verified: whether record_type=1 on that sample actually
*was* a check-out. Before trusting this in production, pull a punch where
you independently know the direction (e.g. watch someone badge in, note
the time, then check what record_type comes back for that exact
timestamp) and confirm it lines up. If a record_type ever shows up packing
extra bits (the FM1100's raw wire format did this -- 0x13/0x23/0x43 packed
verify-method + state together), passthrough is wrong and
_record_type_to_punch() needs real bit-unpacking instead of a straight
map. The warning below will fire if that happens, so it won't fail
silently.
-----------------------------------------------------------------------
"""

import sys
import json
import signal
import traceback

from anviz_ep300 import AnvizEP300

CONNECT_POLL_TIMEOUT_SECONDS  = 5
DOWNLOAD_POLL_TIMEOUT_SECONDS = 60

# How often (in records) to emit a progress trace line during a poll that's
# receiving a lot of data. Without this, a large legitimate transfer (e.g.
# scanner 11's confirmed ~49,967-record backlog) looks IDENTICAL in the logs
# to a genuinely hung connection -- both just show a long gap in stderr
# followed by a timeout. This makes the two distinguishable at a glance.
PROGRESS_LOG_EVERY_N_RECORDS = 500

_sdk = None  # module-level so the CTRL_BREAK handler below can reach it


def _trace(msg: str):
    """Progress marker written to stderr -- see module docstring."""
    print(f"[anviz_worker] {msg}", file=sys.stderr, flush=True)


def _record_type_to_punch(record_type: int) -> int:
    """See PUNCH MAPPING note in the module docstring. Currently a
    passthrough, clamped to the zk library's 0-5 punch range, with a loud
    warning (not a silent drop) if a value falls outside that range."""
    if 0 <= record_type <= 5:
        return record_type
    _trace(
        f"WARNING: record_type={record_type} is outside the expected 0-5 "
        f"punch range -- the passthrough mapping is likely wrong for this "
        f"value (may be a packed bitfield rather than a clean punch code). "
        f"Defaulting punch to 0 (check-in) so the record isn't silently "
        f"dropped, but this needs a real mapping -- don't trust this "
        f"record's punch direction."
    )
    return 0


def _handle_break(signum, frame):
    """On Windows, sync_bio.py sends CTRL_BREAK_EVENT before a hard kill so
    this process gets one chance to log out of the device cleanly. Without
    this, an abrupt TerminateProcess can leave the Anviz device thinking a
    session is still open, causing CONNECT_FAIL on the next attempt (see
    _pull_anviz_logs()'s docstring)."""
    _trace("received CTRL_BREAK_EVENT -- attempting clean disconnect")
    if _sdk is not None:
        try:
            _sdk.stop()
            _trace("sdk.stop() completed during grace period")
        except Exception as e:
            _trace(f"sdk.stop() raised during grace period: {e}")
    sys.exit(1)


def _make_progress_callback():
    """Returns a callback for AnvizEP300(record_callback=...) that logs a
    trace line every PROGRESS_LOG_EVERY_N_RECORDS records, using the
    cur_idx/total_cnt fields already present on every AttendanceRecord.
    This is what lets a genuinely large transfer (confirmed on scanner 11:
    ~49,967 records in device memory) show visible progress in stderr
    instead of looking identical to a hung connection."""
    count = 0

    def _callback(record):
        nonlocal count
        count += 1
        if count == 1 or count % PROGRESS_LOG_EVERY_N_RECORDS == 0:
            _trace(f"progress: received record {count} (device cur_idx={record.cur_idx}/{record.total_cnt})")

    return _callback


def main():
    global _sdk

    if len(sys.argv) < 3:
        print("usage: anviz_pull_worker.py <ip_address> <port> [dll_path]", file=sys.stderr)
        sys.exit(2)

    ip_address = sys.argv[1]
    port = int(sys.argv[2])
    dll_path = sys.argv[3] if len(sys.argv) > 3 else None

    if hasattr(signal, "SIGBREAK"):  # Windows-only, matches CREATE_NEW_PROCESS_GROUP usage
        signal.signal(signal.SIGBREAK, _handle_break)

    _trace(f"starting -- ip={ip_address} port={port}")

    _sdk = AnvizEP300(dll_path=dll_path, record_callback=_make_progress_callback()) \
        if dll_path else AnvizEP300(record_callback=_make_progress_callback())
    _sdk.start()
    _trace(f"SDK version: {_sdk._dll.CChex_Version()}")

    _trace(f"CChex_ClientConnect -- calling ({ip_address}:{port})")
    ret = _sdk.connect(ip_address, port)
    _trace(f"CChex_ClientConnect -- returned {ret}")
    if ret != 1:  # 1 = success for this SDK build (confirmed against a live device)
        raise RuntimeError(f"CChex_ClientConnect failed with code {ret}")

    # Let login complete before requesting a download -- mirrors the
    # standalone anviz_ep300.py __main__ example, which is the path
    # confirmed (via manual test against scanner 11) to actually return
    # real records.
    _sdk.poll(timeout_seconds=CONNECT_POLL_TIMEOUT_SECONDS)
    _trace(f"device flags after login: {_sdk._dev_type_flags}")

    # This is a read-only download. Do not replace it with an SDK erase/clear
    # operation: scanner history must remain on the device for recovery.
    _trace("download_all_records (read-only; device logs retained) -- calling")
    ret = _sdk.download_all_records(1)
    _trace(f"download_all_records -- returned {ret}")
    if ret != 1:
        raise RuntimeError(f"download_all_records failed with code {ret}")

    records = _sdk.poll(timeout_seconds=DOWNLOAD_POLL_TIMEOUT_SECONDS)

    if not records and hasattr(_sdk, "tm_download_all_records"):
        _trace("no records from download_all_records -- trying tm_download_all_records")
        ret = _sdk.tm_download_all_records(1)
        _trace(f"tm_download_all_records -- returned {ret}")
        if ret != 1:
            raise RuntimeError(f"tm_download_all_records failed with code {ret}")
        records = _sdk.poll(timeout_seconds=DOWNLOAD_POLL_TIMEOUT_SECONDS)

    _trace(f"retrieved {len(records)} record(s) -- converting and disconnecting")

    _sdk.stop()

    out = [
        {
            "user_id": r.employee_id,
            "timestamp": r.timestamp.isoformat(),
            "punch": _record_type_to_punch(r.record_type),
        }
        for r in records
    ]
    # Only this line goes to stdout -- everything else above is stderr.
    print(json.dumps(out))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)
