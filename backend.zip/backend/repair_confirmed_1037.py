"""Apply the three punch corrections confirmed by the operator in this case.
Run from backend: python repair_confirmed_1037.py --apply
Without --apply, all three commands preview only. No other employees are corrected.
"""
import argparse
import subprocess
import sys
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true')
parser.add_argument('--confirmed-by', default='Kobe')
args = parser.parse_args()
for stamp, work_date, role in [
    ('2026-09-22 06:46:48', '2026-09-22', 'IN'),
    ('2026-09-22 16:03:31', '2026-09-22', 'OUT'),
    ('2026-09-23 06:35:58', '2026-09-23', 'IN'),
]:
    command = [sys.executable, str(Path(__file__).with_name('confirm_punch.py')),
               '--employee','1037','--punch',stamp,'--date',work_date,
               '--shift','Day Shift','--role',role,'--confirmed-by',args.confirmed_by,
               '--reason','Operator confirmed Day Shift on September 22 and 23']
    if args.apply: command.append('--apply')
    subprocess.run(command, check=True)
print('Finished. Each applied correction commits separately; completed corrections persist if a later one fails.')
