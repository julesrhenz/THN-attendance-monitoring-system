from flask import Flask

from routes.extensions import db, socketio


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "attendance-system-secret-key"
    app.config["SQLALCHEMY_DATABASE_URI"] = (
        "postgresql://postgres:1234@192.9.224.6/attendance_db"
    )
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "connect_args": {"options": "-c search_path=frontend,public"}
    }

    db.init_app(app)
    socketio.init_app(app, cors_allowed_origins="*")

    # Models must be imported (not necessarily used directly) so SQLAlchemy
    # is aware of them, e.g. for `flask db` migrations / create_all().
    from routes import models  # noqa: F401

    from routes.auth import auth_bp
    from routes.data import data_bp
    from routes.attendance import attendance_bp
    from routes.employees import employees_bp
    from routes.groupings import groupings_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(data_bp)
    app.register_blueprint(attendance_bp)
    app.register_blueprint(employees_bp)
    app.register_blueprint(groupings_bp)

    return app


app = create_app()


if __name__ == "__main__":
    print("\n========== ROUTES ==========")
    for rule in app.url_map.iter_rules():
        print(rule)
    print("============================\n")
    socketio.run(app, host="0.0.0.0", port=5000, debug=True)