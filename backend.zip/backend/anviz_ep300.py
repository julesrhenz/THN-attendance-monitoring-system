"""
anviz_ep300.py
--------------
Python ctypes port of the relevant parts of AnvizNew.cs / FrmMain.cs for
retrieving attendance logs from an Anviz EP300 Pro (tc-b_new_sdk.dll,
SDK v44-class).

IMPORTANT ENVIRONMENT NOTE
===========================
tc-b_new_sdk.dll ships in both 32-bit and 64-bit builds depending on which
package you were given -- the sample used during development was 32-bit,
but a 64-bit build is also common. ctypes loads a DLL into the SAME
process as the Python interpreter, so whichever build you have MUST match
your Python interpreter's bitness (32-bit DLL -> 32-bit Python, 64-bit DLL
-> 64-bit Python) or you'll get `OSError: [WinError 193] %1 is not a valid
Win32 application` when loading it. Run diagnose_anviz_dll.py against your
actual DLL file to confirm which build you have and whether it matches
your interpreter before troubleshooting anything else.

This is NOT portable to Linux/Mac -- it's a Windows-only vendor DLL.

CALLING CONVENTION NOTE
=======================
Most exported functions in the SDK explicitly declare
CallingConvention.Cdecl in the C# DllImport attributes. A handful
(CChex_Init, CChex_Start, CChex_Version, CChex_Stop,
CChex_Get_Service_Port, CChex_Set_Service_Disenable) omit the attribute,
which defaults to StdCall in .NET -- but in practice vendor SDKs like this
are almost always uniformly cdecl under the hood and the C# omission is
just an oversight. This module loads the DLL once via ctypes.CDLL (cdecl).
If you get garbage return values or crashes specifically from the
functions listed above, try loading via ctypes.WinDLL for just those
symbols instead (see `_load_stdcall_fallback()` below).

WHAT THIS COVERS
=================
- Starting the SDK's internal listener (CChex_Start)
- Connecting to a device by IP (CCHex_ClientConnect)
- Polling the SDK's internal event queue (CChex_Update) and dispatching:
    * device login/logout events (to learn each device's ID-format flag)
    * attendance records, in both the "old" 5-byte employee-id format and
      the newer VER_4_NEWID (28-byte / unicode employee-id) format used by
      EP300 Pro and similar newer terminals
- Triggering a full or incremental ("new only") log download
- Decoding records into plain Python dicts ready to feed into an
  attendance processor / CSV / DB

It intentionally does NOT port the entire SDK surface (employee/photo/
fingerprint management, network config, etc.) -- only what's needed to
retrieve attendance logs. The full function table is in AnvizNew.cs if you
need to extend this later; the pattern below (ctypes.Structure with
_pack_ = 1, mirroring the [StructLayout(..., Size=N)] struct) is the same
for every other call.

-----------------------------------------------------------------------
PATCH NOTES (this revision)
-----------------------------------------------------------------------
1. ALL debug print() calls now go to stderr, not stdout. This module is
   invoked (via anviz_pull_worker.py) as a subprocess whose stdout is
   captured and parsed as a single JSON array. Any stray print() to
   stdout here would corrupt that payload -- previously only some of
   the debug prints had `file=sys.stderr`, so this was a live bug
   whenever the download path touched a message-handling branch that
   still printed to stdout.
2. poll()'s idle-deadline now only resets when a message actually
   produces a parsed AttendanceRecord (`parsed is not None`), not on
   every message with ret > 0. Previously, any message the SDK doesn't
   turn into a record (e.g. stray DEV_LOGIN/DEV_LOGOUT or an unhandled
   message type arriving during a TM download) kept resetting the idle
   window, so poll() could never time itself out and would only ever
   stop when the outer subprocess-level timeout force-killed it. This
   is the mechanism behind the observed hang after
   CChex_TM_DownloadAllRecords on some devices.
3. The diagnostic print() block after the polling loop referenced
   msg_type / ret / dev_idx, which are only assigned inside the
   `if ret > 0:` branch. If the loop ran for its entire window without
   ever seeing a single message (ret stays 0 throughout), those names
   were never bound and this raised UnboundLocalError on exit. That
   block is now guarded to only run if at least one message arrived.
-----------------------------------------------------------------------
"""

import ctypes
import sys
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable, Optional


# ---------------------------------------------------------------------------
# Message type constants (subset of AnvizNew.cs `MsgType` enum)
# ---------------------------------------------------------------------------
class MsgType:
    RECORD_INFO = 1                 # CCHEX_RET_RECORD_INFO_TYPE
    DEV_LOGIN = 2                   # CCHEX_RET_DEV_LOGIN_TYPE
    DEV_LOGOUT = 3                  # CCHEX_RET_DEV_LOGOUT_TYPE
    GET_NEW_RECORD_INFO = 71        # CCHEX_RET_GET_NEW_RECORD_INFO_TYPE
    RECORD_INFO_CARD_BYTE7 = 251    # CCHEX_RET_RECORD_INFO_CARD_BYTE7_TYPE


# DEV_TYPE_VER_4_NEWID flag from AnvizNew.cs `CustomType` enum.
# FrmMain.cs checks `(DevTypeFlag & 0xff) == DEV_TYPE_VER_4_NEWID` to decide
# which record struct layout a given device uses.
DEV_TYPE_VER_4_NEWID = 0x40


# ---------------------------------------------------------------------------
# ctypes structures (mirrors AnvizNew.cs [StructLayout(..., Size=N)] structs)
# All are packed (Pack=1 equivalent) -- these are wire-format records read
# straight out of a network buffer, so there is no padding between fields.
# ---------------------------------------------------------------------------

class CCHEX_RET_DEV_LOGIN_STRU(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("DevIdx", ctypes.c_int32),
        ("MachineId", ctypes.c_uint32),
        ("Addr", ctypes.c_ubyte * 24),
        ("Version", ctypes.c_ubyte * 8),
        ("DevType", ctypes.c_ubyte * 8),
        ("DevTypeFlag", ctypes.c_uint32),
    ]  # size 52


class CCHEX_RET_DEV_LOGOUT_STRU(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("DevIdx", ctypes.c_int32),
        ("MachineId", ctypes.c_uint32),
        ("Live", ctypes.c_uint32),
        ("Addr", ctypes.c_ubyte * 24),
        ("Version", ctypes.c_ubyte * 8),
        ("DevType", ctypes.c_ubyte * 8),
    ]  # size 52


class CCHEX_RET_RECORD_INFO_STRU(ctypes.Structure):
    """Legacy record format: 5-byte packed BCD-ish employee id."""
    _pack_ = 1
    _fields_ = [
        ("MachineId", ctypes.c_uint32),
        ("NewRecordFlag", ctypes.c_ubyte),
        ("EmployeeId", ctypes.c_ubyte * 5),
        ("Date", ctypes.c_ubyte * 4),
        ("BackId", ctypes.c_ubyte),
        ("RecordType", ctypes.c_ubyte),
        ("WorkType", ctypes.c_ubyte * 3),
        ("Rsv", ctypes.c_ubyte),
        ("CurIdx", ctypes.c_uint32),
        ("TotalCnt", ctypes.c_uint32),
    ]  # size 28


class CCHEX_RET_RECORD_INFO_STRU_VER_4_NEWID(ctypes.Structure):
    """Newer record format (EP300 Pro class devices): 28-byte unicode-ish
    employee id."""
    _pack_ = 1
    _fields_ = [
        ("MachineId", ctypes.c_uint32),
        ("NewRecordFlag", ctypes.c_ubyte),
        ("EmployeeId", ctypes.c_ubyte * 28),
        ("Date", ctypes.c_ubyte * 4),
        ("BackId", ctypes.c_ubyte),
        ("RecordType", ctypes.c_ubyte),
        ("WorkType", ctypes.c_ubyte * 3),
        ("Rsv", ctypes.c_ubyte),
        ("CurIdx", ctypes.c_uint32),
        ("TotalCnt", ctypes.c_uint32),
    ]  # size 51


class CCHEX_RET_RECORD_INFO_STRU_CARD_ID_LEN_7(ctypes.Structure):
    """Card-based record format (7-byte card id)."""
    _pack_ = 1
    _fields_ = [
        ("MachineId", ctypes.c_uint32),
        ("NewRecordFlag", ctypes.c_ubyte),
        ("CardId", ctypes.c_ubyte * 7),
        ("Date", ctypes.c_ubyte * 4),
        ("BackId", ctypes.c_ubyte),
        ("RecordType", ctypes.c_ubyte),
        ("WorkType", ctypes.c_ubyte * 3),
        ("Rsv", ctypes.c_ubyte),
        ("CurIdx", ctypes.c_uint32),
        ("TotalCnt", ctypes.c_uint32),
    ]  # size 30


# ---------------------------------------------------------------------------
# Decoding helpers -- ports of the private helpers in FrmMain.cs
# ---------------------------------------------------------------------------

def swap_uint32(value: int) -> int:
    """Port of FrmMain.swapInt32: byte-swaps a uint32 (device sends dates
    big-endian; BitConverter.ToUInt32 on Windows/little-endian needs the
    swap to read correctly)."""
    return (
        ((value & 0x000000FF) << 24)
        | ((value & 0x0000FF00) << 8)
        | ((value & 0x00FF0000) >> 8)
        | ((value & 0xFF000000) >> 24)
    )


ANVIZ_EPOCH = datetime(2000, 1, 2)


def decode_date(date_bytes) -> datetime:
    """Port of the `new DateTime(2000, 1, 2).AddSeconds(swapInt32(...))`
    pattern used throughout FrmMain.cs."""
    raw = bytes(date_bytes)
    value = int.from_bytes(raw, byteorder="little", signed=False)
    seconds = swap_uint32(value)
    return ANVIZ_EPOCH + timedelta(seconds=seconds)


def employee_id_to_string(employee_id_bytes) -> str:
    """Port of FrmMain.Employee_array_to_srring for the 5-byte legacy
    employee id field."""
    b = bytes(employee_id_bytes)
    temp = bytearray(8)
    for i in range(5):
        temp[8 - 4 - i] = b[i]
    return str(int.from_bytes(bytes(temp), byteorder="little", signed=False))


def card_id_to_string(card_id_bytes) -> str:
    """Port of FrmMain.CardId_array_to_string for the 7-byte card id
    field."""
    b = bytes(card_id_bytes)
    temp = bytearray(8)
    for i in range(7):
        temp[8 - 2 - i] = b[i]
    value = int.from_bytes(bytes(temp), byteorder="little", signed=False)
    if value == 0xFFFFFFFFFFFFFF:
        value = 0
    return str(value)


def byte_to_unicode_string(str_data_bytes) -> str:
    """Port of FrmMain.byte_to_unicode_string: the 28-byte VER_4_NEWID
    employee id field is stored as byte-swapped UTF-16, so we swap pairs
    back and decode as UTF-16."""
    b = bytearray(str_data_bytes)
    n = len(b) - (len(b) % 2)
    swapped = bytearray(len(b))
    for i in range(0, n, 2):
        swapped[i] = b[i + 1]
        swapped[i + 1] = b[i]
    return swapped.decode("utf-16-le", errors="ignore").replace("\x00", "").strip()


# ---------------------------------------------------------------------------
# Parsed record dataclass -- what you'll actually work with downstream
# ---------------------------------------------------------------------------

@dataclass
class AttendanceRecord:
    machine_id: int
    employee_id: str
    timestamp: datetime
    record_type: int
    new_record_flag: int
    cur_idx: int
    total_cnt: int
    dev_idx: int
    source_format: str  # "standard" | "ver4_newid" | "card_byte7"


# ---------------------------------------------------------------------------
# Main SDK wrapper
# ---------------------------------------------------------------------------

class AnvizEP300:
    """
    Minimal wrapper around tc-b_new_sdk.dll for connecting to a device and
    pulling attendance records.

    Typical usage:

        sdk = AnvizEP300(dll_path=r"C:\\path\\to\\tc-b_new_sdk.dll")
        sdk.start()
        sdk.connect("192.168.1.201", 5010)   # device IP/port

        # trigger a download (choose one)
        sdk.download_all_records(dev_idx=0)
        # sdk.download_all_new_records(dev_idx=0)

        # pump the event loop and collect parsed records
        records = sdk.poll(timeout_seconds=15)
        for r in records:
            print(r)

        sdk.stop()
    """

    def __init__(self, dll_path: str = "tc-b_new_sdk.dll",
                 record_callback: Optional[Callable[[AttendanceRecord], None]] = None):
        self._dll_path = dll_path
        self._dll = self._load_dll(dll_path)
        self._configure_signatures()
        self._handle = None
        self._dev_type_flags = {}  # dev_idx -> DevTypeFlag, learned from login events
        self._record_callback = record_callback

    @staticmethod
    def _load_dll(dll_path: str):
        """Loads tc-b_new_sdk.dll, making sure Windows also searches the
        DLL's own directory for any companion/dependency DLLs it needs.
        Since Python 3.8, ctypes no longer does this automatically -- the
        #1 cause of 'Could not find module ... (or one of its
        dependencies)' errors for vendor SDKs like this one that ship
        several DLLs side by side."""
        dll_dir = os.path.dirname(os.path.abspath(dll_path))
        if dll_dir and hasattr(os, "add_dll_directory"):
            os.add_dll_directory(dll_dir)
        try:
            return ctypes.CDLL(dll_path, winmode=0)
        except TypeError:
            # winmode kwarg unsupported on this platform/Python version
            return ctypes.CDLL(dll_path)

    # -- low-level signatures --------------------------------------------

    def _configure_signatures(self):
        d = self._dll

        d.CChex_Version.restype = ctypes.c_uint32
        d.CChex_Version.argtypes = []

        d.CChex_Init.restype = None
        d.CChex_Init.argtypes = []

        d.CChex_Start.restype = ctypes.c_void_p
        d.CChex_Start.argtypes = []

        d.CChex_Stop.restype = None
        d.CChex_Stop.argtypes = [ctypes.c_void_p]

        d.CCHex_ClientConnect.restype = ctypes.c_int
        d.CCHex_ClientConnect.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]

        d.CChex_DownloadAllRecords.restype = ctypes.c_int
        d.CChex_DownloadAllRecords.argtypes = [ctypes.c_void_p, ctypes.c_int]

        d.CChex_DownloadAllNewRecords.restype = ctypes.c_int
        d.CChex_DownloadAllNewRecords.argtypes = [ctypes.c_void_p, ctypes.c_int]

        # ------------------------------------------------------------------
        # Record status
        # ------------------------------------------------------------------

        try:
            d.CChex_GetRecordInfoStatus.restype = ctypes.c_int
            d.CChex_GetRecordInfoStatus.argtypes = [
                ctypes.c_void_p,
                ctypes.c_int,
            ]
        except AttributeError:
            pass

        # ------------------------------------------------------------------
        # Time Management (TM) download functions
        # ------------------------------------------------------------------

        try:
            d.CChex_TM_DownloadAllRecords.restype = ctypes.c_int
            d.CChex_TM_DownloadAllRecords.argtypes = [
                ctypes.c_void_p,
                ctypes.c_int,
            ]
        except AttributeError:
            pass

        try:
            d.CChex_TM_DownloadAllNewRecords.restype = ctypes.c_int
            d.CChex_TM_DownloadAllNewRecords.argtypes = [
                ctypes.c_void_p,
                ctypes.c_int,
            ]
        except AttributeError:
            pass

        d.CChex_Update.restype = ctypes.c_int
        d.CChex_Update.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_int),  # DevIdx[1]
            ctypes.POINTER(ctypes.c_int),  # Type[1]
            ctypes.c_void_p,               # Buff
            ctypes.c_int,                  # Len
        ]

    # -- lifecycle ---------------------------------------------------------

    def start(self):
        """Port of: CChex_Init(); anviz_handle = CChex_Start();
        Falls back to CChex_Start_With_Param(0, 0) if the plain Start
        call returns null -- some SDK builds behave differently between
        the two entry points."""
        self._dll.CChex_Init()
        self._handle = self._dll.CChex_Start()

        if not self._handle:
            self._dll.CChex_Start_With_Param.restype = ctypes.c_void_p
            self._dll.CChex_Start_With_Param.argtypes = [ctypes.c_uint32, ctypes.c_uint32]
            self._handle = self._dll.CChex_Start_With_Param(0, 0)

        if not self._handle:
            raise RuntimeError(
                "CChex_Start (and the CChex_Start_With_Param fallback) both "
                "returned a null handle. This usually means: (1) another "
                "process already has the SDK's internal listener port bound "
                "-- kill any previous run of this script or reboot; (2) the "
                "process needs to run elevated (Administrator) to open a "
                "listening socket; or (3) a firewall/endpoint security tool "
                "is silently blocking the socket bind. Run "
                "diagnose_anviz_dll.py for a fuller check of the DLL load "
                "itself."
            )
        return self._handle

    def stop(self):
        if self._handle:
            self._dll.CChex_Stop(self._handle)
            self._handle = None

    def connect(self, ip: str, port: int) -> int:
        """Port of button6_Click: CCHex_ClientConnect(handle, ip_bytes, port)."""
        self._require_started()
        ip_bytes = ip.encode("ascii")
        ret = self._dll.CCHex_ClientConnect(self._handle, ip_bytes, port)
        return ret

    def download_all_records(self, dev_idx: int) -> int:
        self._require_started()
        return self._dll.CChex_DownloadAllRecords(self._handle, dev_idx)

    def tm_download_all_records(self, dev_idx: int):
        self._require_started()
        return self._dll.CChex_TM_DownloadAllRecords(
            self._handle,
            dev_idx,
        )

    def tm_download_all_new_records(self, dev_idx: int):
        self._require_started()
        return self._dll.CChex_TM_DownloadAllNewRecords(
            self._handle,
            dev_idx,
        )

    def get_record_status(self, dev_idx: int):
        self._require_started()

        try:
            return self._dll.CChex_GetRecordInfoStatus(
                self._handle,
                dev_idx,
            )
        except AttributeError:
            return None

    def download_all_new_records(self, dev_idx: int) -> int:
        """'New' = only records not yet downloaded/flagged, per SDK semantics."""
        self._require_started()
        return self._dll.CChex_DownloadAllNewRecords(self._handle, dev_idx)

    def _require_started(self):
        if not self._handle:
            raise RuntimeError("Call start() before using the SDK handle.")

    # -- event pump ----------------------------------------------------------

    def poll(self, timeout_seconds: float = 10.0, idle_sleep: float = 0.02,
             buffer_len: int = 32000):
        """
        Port of FrmMain.timer1_Tick's inner while-loop, but run for a bounded
        window instead of on a UI timer. Returns a list of AttendanceRecord.

        The idle deadline resets only when a message actually yields a
        parsed AttendanceRecord -- NOT on every message with ret > 0. A
        device can emit messages CChex_Update reports as "received" (login/
        logout events, unrecognized message types, etc.) that never turn
        into a record; if those also reset the deadline, poll() can run
        indefinitely as long as the device keeps talking at all, even if
        it's stopped sending anything download-related. That previously
        showed up as poll() never returning on its own -- only the outer
        subprocess-level timeout in sync_bio.py's _pull_anviz_logs() ever
        ended the call.
        """
        self._require_started()
        records = []
        dev_idx_buf = ctypes.c_int(0)
        type_buf = ctypes.c_int(0)
        buff = (ctypes.c_ubyte * buffer_len)()

        last_msg_type = None
        last_ret = 0
        last_dev_idx = None
        saw_any_message = False

        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            ret = self._dll.CChex_Update(
                self._handle,
                ctypes.byref(dev_idx_buf),
                ctypes.byref(type_buf),
                ctypes.byref(buff),
                buffer_len,
            )

            if ret > 0:
                saw_any_message = True
                msg_type = type_buf.value
                dev_idx = dev_idx_buf.value
                last_msg_type, last_ret, last_dev_idx = msg_type, ret, dev_idx

                print(
                    f"Message={msg_type} Length={ret} Dev={dev_idx}",
                    file=sys.stderr,
                )
                print(bytes(buff[:ret]).hex(" "), file=sys.stderr)

                parsed = self._dispatch(msg_type, dev_idx, buff)
                if parsed is not None:
                    records.append(parsed)
                    deadline = time.monotonic() + timeout_seconds  # only reset on real records
                    if self._record_callback:
                        self._record_callback(parsed)
            else:
                time.sleep(idle_sleep)

        # Only emit this diagnostic if at least one message actually arrived
        # during the poll window -- msg_type/ret/dev_idx are otherwise
        # unbound (an all-idle poll, e.g. device never sent anything at
        # all), which previously raised UnboundLocalError here.
        if saw_any_message:
            print(
                f"\nSDK MESSAGE type={last_msg_type} len={last_ret} dev={last_dev_idx}",
                file=sys.stderr,
            )
            print(bytes(buff[:last_ret]).hex(" "), file=sys.stderr)
        else:
            print("SDK MESSAGE: no messages received during this poll window", file=sys.stderr)

        return records

    def _dispatch(self, msg_type: int, dev_idx: int, buff) -> Optional[AttendanceRecord]:
        if msg_type == MsgType.DEV_LOGIN:
            info = ctypes.cast(buff, ctypes.POINTER(CCHEX_RET_DEV_LOGIN_STRU)).contents
            self._dev_type_flags[dev_idx] = info.DevTypeFlag
            print(f"Unhandled message: type={msg_type} dev={dev_idx}", file=sys.stderr)
            print(bytes(buff[:64]).hex(), file=sys.stderr)
            return None

        if msg_type == MsgType.DEV_LOGOUT:
            self._dev_type_flags.pop(dev_idx, None)
            print("=" * 80, file=sys.stderr)
            print("UNKNOWN MESSAGE", file=sys.stderr)
            print("Type :", msg_type, file=sys.stderr)
            print("Length:", ctypes.sizeof(buff), file=sys.stderr)
            print(bytes(buff[:64]).hex(), file=sys.stderr)
            print("=" * 80, file=sys.stderr)
            return None

        if msg_type == MsgType.RECORD_INFO_CARD_BYTE7:
            info = ctypes.cast(
                buff, ctypes.POINTER(CCHEX_RET_RECORD_INFO_STRU_CARD_ID_LEN_7)
            ).contents
            return AttendanceRecord(
                machine_id=info.MachineId,
                employee_id=card_id_to_string(info.CardId),
                timestamp=decode_date(info.Date),
                record_type=info.RecordType,
                new_record_flag=info.NewRecordFlag,
                cur_idx=info.CurIdx,
                total_cnt=info.TotalCnt,
                dev_idx=dev_idx,
                source_format="card_byte7",
            )

        if msg_type in (MsgType.RECORD_INFO, MsgType.GET_NEW_RECORD_INFO):
            flag = self._dev_type_flags.get(dev_idx, 0)
            if (flag & 0xFF) == DEV_TYPE_VER_4_NEWID:
                info = ctypes.cast(
                    buff, ctypes.POINTER(CCHEX_RET_RECORD_INFO_STRU_VER_4_NEWID)
                ).contents
                emp_id = byte_to_unicode_string(bytes(info.EmployeeId))
                fmt = "ver4_newid"
            else:
                info = ctypes.cast(
                    buff, ctypes.POINTER(CCHEX_RET_RECORD_INFO_STRU)
                ).contents
                emp_id = employee_id_to_string(info.EmployeeId)
                fmt = "standard"

            return AttendanceRecord(
                machine_id=info.MachineId,
                employee_id=emp_id,
                timestamp=decode_date(info.Date),
                record_type=info.RecordType,
                new_record_flag=info.NewRecordFlag,
                cur_idx=info.CurIdx,
                total_cnt=info.TotalCnt,
                dev_idx=dev_idx,
                source_format=fmt,
            )

        # Unhandled message types (employee mgmt, config, etc.) are ignored
        # here -- extend _dispatch if your processor needs them too.
        print("=" * 80, file=sys.stderr)
        print("UNKNOWN SDK MESSAGE", file=sys.stderr)
        print("Type   :", msg_type, file=sys.stderr)
        print("DevIdx :", dev_idx, file=sys.stderr)
        print("Length :", ctypes.sizeof(buff), file=sys.stderr)
        print("Raw    :", bytes(buff[:64]).hex(" "), file=sys.stderr)
        print("=" * 80, file=sys.stderr)

        return None


# ---------------------------------------------------------------------------
# Example end-to-end usage
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import csv

    if len(sys.argv) < 3:
        print("Usage: python anviz_ep300.py <device_ip> <device_port> [dll_path]")
        sys.exit(1)

    device_ip = sys.argv[1]
    device_port = int(sys.argv[2])
    dll_path = sys.argv[3] if len(sys.argv) > 3 else "tc-b_new_sdk.dll"

    sdk = AnvizEP300(dll_path=dll_path)
    sdk.start()
    print(f"SDK version: {sdk._dll.CChex_Version()}")

    ret = sdk.connect(device_ip, device_port)
    print(f"Connect returned: {ret}")

    # Give the device a moment to log in before triggering the download.
    login_records = sdk.poll(timeout_seconds=20)

    dev_idx = 0  # first connected device; adjust if you manage multiple
    print("Requesting all records...")
    sdk.download_all_records(dev_idx)

    all_records = sdk.poll(timeout_seconds=120)
    print(f"Retrieved {len(all_records)} records")

    out_path = "attendance_records.csv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "machine_id", "employee_id", "timestamp", "record_type",
            "new_record_flag", "cur_idx", "total_cnt", "dev_idx", "source_format",
        ])
        for r in all_records:
            writer.writerow([
                r.machine_id, r.employee_id, r.timestamp.isoformat(),
                r.record_type, r.new_record_flag, r.cur_idx, r.total_cnt,
                r.dev_idx, r.source_format,
            ])
    print(f"Wrote {out_path}")

    sdk.stop()