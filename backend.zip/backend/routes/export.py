from flask import Blueprint, send_file
from sqlalchemy import text as sa_text
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from io import BytesIO
from datetime import datetime
from collections import defaultdict
import traceback
import re

from routes.extensions import db
from routes.decorators import login_required

export_bp = Blueprint("export", __name__)

# ── Style constants ───────────────────────────────────────────────
FONT_NAME    = "Arial"

AGENCY_COLORS = {
    "THN":     "1F4E79",
    "CCI":     "375623",
    "EMIS":    "7B2C2C",
    "NATCORP": "4A235A",
}
DEFAULT_AGENCY_COLOR = "404040"

HEADER_BG   = "2E75B6"
HEADER_FONT = "FFFFFF"
INFO_BG     = "FFF2CC"
INFO_FONT   = "000000"

THIN   = Side(style="thin", color="000000")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def _make_font(bold=False, size=10, color="000000"):
    return Font(name=FONT_NAME, bold=bold, size=size, color=color)


def _make_fill(hex_color: str):
    return PatternFill("solid", start_color=hex_color, fgColor=hex_color)


def _center():
    return Alignment(horizontal="center", vertical="center")


def _col_widths(ws, widths: dict):
    for col_letter, width in widths.items():
        ws.column_dimensions[col_letter].width = width


def _write_sheet(wb: Workbook, sheet_name: str, employees: list[dict], shift: str):
    ws         = wb.create_sheet(title=sheet_name)
    HEADERS    = ["HC", "LAST NAME", "FIRST NAME", "EMP", "FULL NAME",
                  "DATE HIRED", "PROCESS", "LINE", "EMP", "TENURE", "REMARKS"]
    COL_WIDTHS = {
        "A": 5,  "B": 18, "C": 18, "D": 8,  "E": 28,
        "F": 14, "G": 20, "H": 14, "I": 10, "J": 8, "K": 22,
    }
    _col_widths(ws, COL_WIDTHS)

    # ── Row 9: info row ────────────────────────────────────────────
    line_label  = re.sub(r'\s*(2ND\s+)?(?:DAY|NIGHT)$', '', sheet_name.upper()).strip()
    shift_label = "DAY" if "day" in shift.lower() else "NIGHT"

    info_fill = _make_fill(INFO_BG)
    info_font = _make_font(bold=True, size=10, color=INFO_FONT)

    ws.row_dimensions[9].height = 20
    ws.merge_cells("A9:C9")
    ws["A9"] = "LINE / ITEM :"
    ws["A9"].font      = info_font
    ws["A9"].fill      = info_fill
    ws["A9"].alignment = _center()

    ws.merge_cells("D9:G9")
    ws["D9"] = line_label
    ws["D9"].font      = _make_font(bold=True, size=11, color="1F4E79")
    ws["D9"].fill      = info_fill
    ws["D9"].alignment = _center()

    ws.merge_cells("H9:I9")
    ws["H9"] = shift_label
    ws["H9"].font      = _make_font(bold=True, size=11, color="C00000")
    ws["H9"].fill      = info_fill
    ws["H9"].alignment = _center()

    ws["J9"] = len(employees)
    ws["J9"].font      = _make_font(bold=True, size=11)
    ws["J9"].fill      = info_fill
    ws["J9"].alignment = _center()

    # ── Group employees by agency ──────────────────────────────────
    agency_groups: dict[str, list] = defaultdict(list)
    for emp in employees:
        agency_groups[(emp.get("emp") or "UNKNOWN").upper()].append(emp)

    current_row = 11
    hc_global   = 1

    for agency, members in agency_groups.items():
        agency_color = AGENCY_COLORS.get(agency, DEFAULT_AGENCY_COLOR)
        ws.row_dimensions[current_row].height = 18

        ws.merge_cells(f"A{current_row}:K{current_row}")
        cell           = ws[f"A{current_row}"]
        cell.value     = agency
        cell.font      = _make_font(bold=True, size=11, color="FFFFFF")
        cell.fill      = _make_fill(agency_color)
        cell.alignment = _center()
        current_row   += 1

        ws.row_dimensions[current_row].height = 16
        for col_idx, header in enumerate(HEADERS, start=1):
            cell           = ws.cell(row=current_row, column=col_idx, value=header)
            cell.font      = _make_font(bold=True, color=HEADER_FONT)
            cell.fill      = _make_fill(HEADER_BG)
            cell.alignment = _center()
            cell.border    = BORDER
        current_row += 1

        for emp in members:
            ws.row_dimensions[current_row].height = 15

            date_hired = emp.get("date_hired")
            if date_hired and not isinstance(date_hired, str):
                date_hired = str(date_hired)

            row_data = [
                hc_global,
                emp.get("last_name",  ""),
                emp.get("first_name", ""),
                emp.get("emp_no",     ""),
                emp.get("full_name",  ""),
                date_hired or "",
                emp.get("process",    ""),
                emp.get("line",       ""),
                agency,
                emp.get("tenure",     ""),
                "",
            ]

            for col_idx, value in enumerate(row_data, start=1):
                cell           = ws.cell(row=current_row, column=col_idx, value=value)
                cell.font      = _make_font(size=10)
                cell.alignment = Alignment(vertical="center")
                cell.border    = BORDER

            hc_global   += 1
            current_row += 1

        current_row += 1   # blank row between agency blocks

    ws.freeze_panes = "A12"


# ── Route ─────────────────────────────────────────────────────────
@export_bp.route("/api/export-groupings")
@login_required
def export_groupings():
    try:
        with db.engine.connect() as conn:
            # No batch_id — employee_groupings is a flat current-state table
            rows = conn.execute(sa_text("""
                SELECT
                    eg.emp_id,
                    eg.emp,
                    eg.emp_no,
                    eg.last_name,
                    eg.first_name,
                    eg.full_name,
                    eg.line_name,
                    eg.shift,
                    eg.process,
                    eg.line,
                    eg.date_hired,
                    eg.tenure
                FROM frontend.employee_groupings eg
                ORDER BY eg.line_name, eg.shift, eg.full_name
            """)).mappings().all()

        if not rows:
            return {"error": "No employees found in groupings."}, 404

        # ── Group by (line_name, shift) → one sheet each ──────────
        sheets: dict[str, list] = defaultdict(list)
        for r in rows:
            line_name    = (r["line_name"] or "").strip().upper()
            shift        = (r["shift"]     or "Day Shift").strip()
            shift_suffix = "NIGHT" if "night" in shift.lower() else "DAY"
            sheet_name   = f"{line_name} {shift_suffix}"
            sheets[sheet_name].append(dict(r))

        # ── Build workbook ─────────────────────────────────────────
        wb = Workbook()

        # Remove the default sheet safely — active can be None
        if wb.active is not None:
            wb.remove(wb.active)

        for sheet_name, employees in sorted(sheets.items()):
            _write_sheet(wb, sheet_name, employees, employees[0].get("shift", "Day Shift"))

        # ── Stream to client ───────────────────────────────────────
        buffer = BytesIO()
        wb.save(buffer)
        buffer.seek(0)

        export_name = f"ATT_GROUPINGS_EXPORT_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

        return send_file(
            buffer,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=export_name,
        )

    except Exception as e:
        traceback.print_exc()
        return {"error": str(e)}, 500