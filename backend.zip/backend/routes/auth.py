from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import text as sa_text
from sqlalchemy.exc import IntegrityError
from datetime import datetime, timedelta
import traceback
import secrets

from extensions import db
from routes.decorators import login_required, admin_required, staff_required

auth_bp = Blueprint("auth", __name__)

# Must match the DB check constraint: frontend.users_roles_check
ROLES        = {"Admin", "Supervisor", "Employee"}
DEFAULT_ROLE = "Employee"

# Brute-force protection — track failed attempts per username in memory.
# For production with multiple workers, move this to Redis or the DB.
_failed_attempts: dict[str, dict] = {}
MAX_ATTEMPTS    = 5       # lock after this many failures
LOCKOUT_MINUTES = 15      # locked for this long


def _check_lockout(username: str) -> tuple[bool, int]:
    """
    Returns (is_locked, seconds_remaining).
    Cleans up expired lockouts automatically.
    """
    entry = _failed_attempts.get(username)
    if not entry:
        return False, 0

    locked_until = entry.get("locked_until")
    if locked_until and datetime.utcnow() < locked_until:
        remaining = int((locked_until - datetime.utcnow()).total_seconds())
        return True, remaining

    # Lockout expired — clear it
    if locked_until and datetime.utcnow() >= locked_until:
        _failed_attempts.pop(username, None)

    return False, 0


def _record_failure(username: str):
    entry = _failed_attempts.setdefault(username, {"count": 0, "locked_until": None})
    entry["count"] += 1
    if entry["count"] >= MAX_ATTEMPTS:
        entry["locked_until"] = datetime.utcnow() + timedelta(minutes=LOCKOUT_MINUTES)


def _clear_failures(username: str):
    _failed_attempts.pop(username, None)


def role_context() -> dict:
    """Inject role info into every rendered template."""
    role     = session.get("role", "")
    is_admin = role == "Admin"
    is_staff = role in ("Admin", "Supervisor")
    return {
        "role_info": {
            "role":      role,
            "is_admin":  is_admin,
            "is_staff":  is_staff,
            "is_viewer": not is_staff and session.get("logged_in", False),
            "can_write": is_admin,
        }
    }


# ── Pages ──────────────────────────────────────────────────────────────────
@auth_bp.route("/")
def home():
    return render_template("index.html")


@auth_bp.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", **role_context())


@auth_bp.route("/maindashboard")
@login_required
def maindashboard():
    return render_template("maindashboard.html", **role_context())


@auth_bp.route("/overtime")
@login_required
def overtime():
    return render_template("overtime.html", **role_context())


@auth_bp.route("/attendance-logs")
@staff_required
def attendance_logs_page():
    return render_template("attendance_logs.html", **role_context())


@auth_bp.route("/employee_management")
@staff_required
def employee_management():
    return render_template("employee_management.html", **role_context())


# ── Login ──────────────────────────────────────────────────────────────────
@auth_bp.route("/login", methods=["POST"])
def login():
    try:
        data     = request.get_json(force=True, silent=True) or {}
        username = data.get("username", "").strip()
        password = data.get("password", "")

        if not username or not password:
            return jsonify({"success": False, "message": "Username and password are required."})

        # ── Lockout check ──────────────────────────────────────────────────
        is_locked, seconds_left = _check_lockout(username)
        if is_locked:
            minutes_left = max(1, seconds_left // 60)
            return jsonify({
                "success": False,
                "message": f"Account temporarily locked due to too many failed attempts. "
                           f"Try again in {minutes_left} minute(s).",
                "locked":  True,
            }), 429

        # ── Credential check ───────────────────────────────────────────────
        with db.engine.connect() as conn:
            row = conn.execute(sa_text(
                "SELECT username, password_hash, roles "
                "FROM frontend.users WHERE username = :username LIMIT 1"
            ), {"username": username}).fetchone()

        if not row or not check_password_hash(row.password_hash, password):
            _record_failure(username)
            entry    = _failed_attempts.get(username, {})
            attempts = entry.get("count", 0)
            remaining = max(0, MAX_ATTEMPTS - attempts)

            if attempts >= MAX_ATTEMPTS:
                return jsonify({
                    "success": False,
                    "message": f"Account locked for {LOCKOUT_MINUTES} minutes after too many failed attempts.",
                    "locked":  True,
                }), 429

            return jsonify({
                "success": False,
                "message": f"Invalid username or password. "
                           f"{remaining} attempt(s) remaining before lockout.",
            })

        # ── Success ────────────────────────────────────────────────────────
        _clear_failures(username)

        session.permanent    = True   # respect PERMANENT_SESSION_LIFETIME
        session["logged_in"] = True
        session["username"]  = row.username
        session["role"]      = row.roles
        session["login_at"]  = datetime.utcnow().isoformat()

        return jsonify({
            "success":     True,
            "role":        row.roles,
            "is_admin":    row.roles == "Admin",
            "is_staff":    row.roles in ("Admin", "Supervisor"),
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": f"Server error: {str(e)}"}), 500


# ── Register  (Admin only — creates accounts directly) ────────────────────
@auth_bp.route("/register", methods=["POST"])
@admin_required
def register():
    try:
        data       = request.get_json(force=True, silent=True) or {}
        first_name = data.get("first_name", "").strip()
        last_name  = data.get("last_name",  "").strip()
        username   = data.get("username",   "").strip()
        password   = data.get("password",   "")
        roles      = data.get("roles",      DEFAULT_ROLE).strip()

        if not all([first_name, last_name, username, password]):
            return jsonify({"success": False, "message": "All fields are required."})
        if len(password) < 8:
            return jsonify({"success": False, "message": "Password must be at least 8 characters."})
        if roles not in ROLES:
            return jsonify({
                "success": False,
                "message": f"Invalid role. Must be one of: {sorted(ROLES)}",
            }), 400

        try:
            with db.engine.begin() as conn:
                if conn.execute(sa_text(
                    "SELECT 1 FROM frontend.users WHERE username = :u LIMIT 1"
                ), {"u": username}).fetchone():
                    return jsonify({"success": False, "message": "Username is already taken."})

                conn.execute(sa_text(
                    "INSERT INTO frontend.users "
                    "(username, password_hash, first_name, last_name, roles) "
                    "VALUES (:username, :password_hash, :first_name, :last_name, :roles)"
                ), {
                    "username":      username,
                    "password_hash": generate_password_hash(password),
                    "first_name":    first_name,
                    "last_name":     last_name,
                    "roles":         roles,
                })

        except IntegrityError as e:
            if "users_roles_check" in str(e.orig):
                return jsonify({
                    "success": False,
                    "message": f"Invalid role. Must be one of: {sorted(ROLES)}",
                }), 400
            raise

        return jsonify({
            "success": True,
            "message": f"Account '{username}' created as {roles}.",
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": f"Server error: {str(e)}"}), 500


# ── Invite system ──────────────────────────────────────────────────────────
@auth_bp.route("/api/invite/generate", methods=["POST"])
@admin_required
def generate_invite():
    """
    Admin generates a one-time invite link.
    The link lets someone register without needing Admin access —
    but they are always created as Employee (Viewer) role.
    Only an Admin can later promote them.
    """
    try:
        data       = request.get_json(force=True, silent=True) or {}
        hours      = int(data.get("expires_hours", 24))
        token      = secrets.token_urlsafe(32)

        with db.engine.begin() as conn:
            conn.execute(sa_text("""
                INSERT INTO frontend.invite_tokens
                    (token, created_by, expires_at)
                VALUES
                    (:token, :created_by, NOW() + :interval)
            """), {
                "token":      token,
                "created_by": session.get("username", "system"),
                "interval":   f"{hours} hours",
            })

        invite_url = f"/register/invite?token={token}"
        return jsonify({
            "success":    True,
            "token":      token,
            "invite_url": invite_url,
            "expires_in": f"{hours} hour(s)",
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": str(e)}), 500


@auth_bp.route("/register/invite", methods=["POST"])
def register_via_invite():
    """
    Self-registration using a valid invite token.
    Role is always forced to Employee — cannot be chosen by the registrant.
    """
    try:
        data       = request.get_json(force=True, silent=True) or {}
        token      = data.get("token", "").strip()
        first_name = data.get("first_name", "").strip()
        last_name  = data.get("last_name",  "").strip()
        username   = data.get("username",   "").strip()
        password   = data.get("password",   "")

        if not all([token, first_name, last_name, username, password]):
            return jsonify({"success": False, "message": "All fields are required."}), 400
        if len(password) < 8:
            return jsonify({"success": False, "message": "Password must be at least 8 characters."})

        with db.engine.begin() as conn:

            # Validate token
            invite = conn.execute(sa_text("""
                SELECT id FROM frontend.invite_tokens
                WHERE token      = :token
                  AND used       = FALSE
                  AND expires_at > NOW()
            """), {"token": token}).fetchone()

            if not invite:
                return jsonify({
                    "success": False,
                    "message": "Invalid or expired invite link. Please request a new one.",
                }), 403

            # Check username availability
            if conn.execute(sa_text(
                "SELECT 1 FROM frontend.users WHERE username = :u LIMIT 1"
            ), {"u": username}).fetchone():
                return jsonify({"success": False, "message": "Username is already taken."})

            # Create account — role always Employee, never Admin
            conn.execute(sa_text(
                "INSERT INTO frontend.users "
                "(username, password_hash, first_name, last_name, roles) "
                "VALUES (:username, :password_hash, :first_name, :last_name, :roles)"
            ), {
                "username":      username,
                "password_hash": generate_password_hash(password),
                "first_name":    first_name,
                "last_name":     last_name,
                "roles":         "Employee",   # ← hardcoded, never from request
            })

            # Mark token as used — one-time only
            conn.execute(sa_text("""
                UPDATE frontend.invite_tokens
                SET used = TRUE, used_by = :username, used_at = NOW()
                WHERE token = :token
            """), {"token": token, "username": username})

        return jsonify({
            "success": True,
            "message": f"Account '{username}' created. You can now log in.",
        })

    except IntegrityError:
        return jsonify({"success": False, "message": "Username is already taken."}), 409
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": f"Server error: {str(e)}"}), 500


@auth_bp.route("/api/invite/list")
@admin_required
def list_invites():
    """Show Admin all pending and used invite tokens."""
    try:
        with db.engine.connect() as conn:
            rows = conn.execute(sa_text("""
                SELECT token, created_by, created_at, expires_at,
                       used, used_by, used_at
                FROM frontend.invite_tokens
                ORDER BY created_at DESC
                LIMIT 50
            """)).fetchall()

        return jsonify([{
            "token":      r[0][:8] + "...",   # never expose full token
            "created_by": r[1],
            "created_at": str(r[2]),
            "expires_at": str(r[3]),
            "used":       r[4],
            "used_by":    r[5],
            "used_at":    str(r[6]) if r[6] else None,
            "expired":    r[3] < datetime.utcnow(),
        } for r in rows])

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ── Role management (Admin only) ───────────────────────────────────────────
@auth_bp.route("/api/users/<username>/role", methods=["PUT"])
@admin_required
def update_user_role(username: str):
    """Admin can change any user's role — including promoting to Admin."""
    try:
        data     = request.get_json(force=True, silent=True) or {}
        new_role = data.get("role", "").strip()

        if new_role not in ROLES:
            return jsonify({
                "success": False,
                "message": f"Invalid role. Must be one of: {sorted(ROLES)}",
            }), 400

        # Prevent Admin from demoting themselves — avoids lockout
        if username == session.get("username") and new_role != "Admin":
            return jsonify({
                "success": False,
                "message": "You cannot change your own role.",
            }), 400

        with db.engine.begin() as conn:
            result = conn.execute(sa_text("""
                UPDATE frontend.users SET roles = :role
                WHERE username = :username
            """), {"role": new_role, "username": username})

            if result.rowcount == 0:
                return jsonify({"success": False, "message": "User not found."}), 404

        return jsonify({
            "success": True,
            "message": f"'{username}' is now {new_role}.",
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": str(e)}), 500


# ── Logout ─────────────────────────────────────────────────────────────────
@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect("/")


# ── Session info ───────────────────────────────────────────────────────────
@auth_bp.route("/api/me")
@login_required
def me():
    return jsonify({
        "username": session.get("username"),
        "role":     session.get("role"),
        "is_admin": session.get("role") == "Admin",
        "is_staff": session.get("role") in ("Admin", "Supervisor"),
    })