from flask import Blueprint, request, jsonify
from sqlalchemy import text as sa_text
from datetime import date, datetime, timedelta, time as dtime
import traceback
import requests
from routes.attendance import is_valid_employee_record
from routes.extensions import db
from routes.decorators import login_required

data_bp = Blueprint("data", __name__)

ATTENDANCE_URL      = "http://192.9.224.6:5000/attendance/attendance_summary"
ATTENDANCE_LOGS_URL = "http://192.9.224.6:5000/attendance/attendance-logs"
EMPLOYEES_URL       = "http://192.9.224.6:5000/employee_groupings"
ALLOWED_DEPARTMENTS = {"production", "quality", "technical", "assembly"}
INVALID_CHECKIN     = {"", "-", "none", "null", "no check-in yet", "n/a", "na"}

NIGHT_SHIFT_OT_END  = dtime(9, 0, 0)

# Raw emp_no (e.g. "12") is only unique WITHIN one agency — THN, CCI,
# NATCORP, and EMIS all number their own employees independently, so the
# same "12" can legitimately belong to four different people. The only
# value that's globally unique across agencies is the prefixed emp_id
# (e.g. "12" for THN, "N-12" for NATCORP, "C-12" for CCI, "E-12" for EMIS)
# as stored in frontend.employee_groupings.emp_id. Every lookup dict in
# this file MUST be keyed by that prefixed emp_id — keying by bare emp_no
# lets two different agencies' employees silently collide/overwrite each
# other (e.g. THN "12" vs NATCORP "N-12" both reducing to "12").
AGENCY_PREFIX_BY_ID = {1: "", 2: "C-", 3: "N-", 4: "E-"}


def is_valid_checkin(value: object) -> bool:
    if not value:
        return False
    return str(value).strip().lower() not in INVALID_CHECKIN


def is_admin_employee(emp: dict) -> bool:
    """
    True if this employee's master-list department is known and falls
    outside ALLOWED_DEPARTMENTS. Employees with no master-list match keep
    their existing line assignment (we have no department to judge by),
    consistent with the "don't reject on missing info" policy elsewhere
    in this file.
    """
    dept = str(emp.get("department", "") or "").strip().lower()
    return bool(dept) and dept not in ALLOWED_DEPARTMENTS


def normalize_id(value: object) -> str:
    """
    Excel numeric ID cells are read by openpyxl as float (1222 -> 1222.0),
    so employee_groupings.emp_no can contain "1222.0" while every other
    source (attendance-logs API, employee master) uses "1222". Strip a
    trailing ".0" off a purely-numeric string so IDs match across sources.
    """
    s = str(value or "").strip()
    if s.endswith(".0") and s[:-2].isdigit():
        return s[:-2]
    return s


def build_prefixed_id(raw_emp_no: object, agency_field: object) -> str:
    """
    Turns a raw scanner/master emp_no ("12") into the globally-unique,
    agency-prefixed emp_id ("12" for THN, "N-12" for NATCORP, ...), the
    same format used as the primary key in frontend.employee_groupings.

    agency_field may come in as an int FK (1/2/3/4, from employee_groupings
    or the master list's `emp` column) or as a string agency code
    ("THN"/"CCI"/"NATCORP"/"EMIS", as sometimes returned by attendance-logs).
    Falls back to "" (THN/no prefix) if the agency can't be resolved, since
    that's the majority case and matches prior behavior for unresolvable
    records rather than dropping them.
    """
    raw_id = normalize_id(raw_emp_no)
    if not raw_id:
        return ""

    prefix = ""
    if isinstance(agency_field, int):
        prefix = AGENCY_PREFIX_BY_ID.get(agency_field, "")
    elif agency_field is not None:
        code = str(agency_field).strip().upper()
        if code.isdigit():
            prefix = AGENCY_PREFIX_BY_ID.get(int(code), "")
        else:
            prefix = {"THN": "", "CCI": "C-", "NATCORP": "N-", "EMIS": "E-"}.get(code, "")

    return f"{prefix}{raw_id}".upper()


def parse_date(value: object):
    for fmt in ("%Y-%m-%d", "%a, %d %b %Y %H:%M:%S GMT"):
        try:
            return datetime.strptime(str(value).strip(), fmt).date()
        except Exception:
            pass
    return None


def is_in_todays_window(att_date_str: str, shift_name: str, today: date, now: dtime) -> bool:
    """
    Night-shift records are stamped with the date the shift started, so once
    midnight passes they'd be excluded by a plain `att_date == today` check.
    Treat a night-shift record from yesterday as still part of today's window
    until the night-shift OT cutoff (09:00).
    """
    try:
        att_date = datetime.strptime(att_date_str.strip(), "%Y-%m-%d").date()
    except (ValueError, AttributeError):
        return False
    if att_date == today:
        return True
    is_night = "night" in (shift_name or "").lower()
    return is_night and att_date == today - timedelta(days=1) and now <= NIGHT_SHIFT_OT_END


def _fetch_time_in_map() -> dict:
    """
    prefixed emp_id -> today's time_in string, sourced from attendance-logs —
    the same source of truth determine_status()/dashboard_summary already
    use, so the time shown in the line summary modal matches the status
    computed everywhere else. Skips orphaned/unknown-resigned rows and
    anything outside today's attendance window (with night-shift rollover
    handled the same way as dashboard_summary).
    """
    from routes.attendance import is_valid_employee_record

    try:
        records = requests.get(ATTENDANCE_LOGS_URL, timeout=10).json().get("data", [])
    except Exception as e:
        print("ATTENDANCE LOGS (time_in) ERROR:", e)
        return {}

    today, now = date.today(), datetime.now().time()
    time_in_map: dict[str, str] = {}

    for record in records:
        if not is_valid_employee_record(record):
            continue
        emp_id = build_prefixed_id(record.get("emp_no", ""), record.get("emp"))
        att_date   = str(record.get("attendance_date", "")).strip()
        shift_name = record.get("shift_name", "")
        if not emp_id or not is_in_todays_window(att_date, shift_name, today, now):
            continue
        time_in_map[emp_id] = record.get("time_in")

    return time_in_map


@data_bp.route("/api/data")
@login_required
def data():
    """
    Roster-first design: employee_groupings (the imported Excel roster,
    already saved in the DB) is the source of truth for WHO exists and
    which line/shift/section they belong to. attendance-logs is matched
    against that roster by the agency-prefixed emp_id (NOT bare emp_no --
    emp_no alone is only unique within a single agency, so two different
    agencies' employees sharing the same raw number would otherwise
    collide and silently overwrite one another's attendance/master data)
    to determine EACH person's status.

    Department is no longer part of the present/late/absent decision —
    a real check-in can no longer be silently dropped because a
    department string didn't match an allow-list (this was the root
    cause of employees showing "Absent" despite a valid time_in).
    department is only used, if present, as display/fallback info.

    Status is computed with determine_roster_status() from attendance.py
    so the dashboard grid, the line summary modal's sheet-level tally,
    and this endpoint all agree on the same present/late/absent rule.
    """
    from routes.attendance import is_valid_employee_record, determine_roster_status

    # ── Employee master (name/agency/department fallback only — NOT a filter) ──
    try:
        master_employees = requests.get(EMPLOYEES_URL, timeout=10).json()
    except Exception as e:
        print("EMPLOYEE API ERROR:", e)
        master_employees = []

    master_map: dict[str, dict] = {}
    for emp in master_employees:
        try:
            emp_id = build_prefixed_id(emp.get("emp_no", ""), emp.get("emp"))
            if not emp_id:
                continue
            # full_name is already provided directly by this endpoint
            # (e.g. "Alzate, Ramil"), unlike the old /employees endpoint
            # which required joining first_name + last_name.
            full_name = emp.get("full_name") or " ".join(filter(None, [
                emp.get("first_name", ""), emp.get("last_name", "")
            ]))
            master_map[emp_id] = {
                "id": emp_id, "name": full_name,
                "agency": emp_id.split("-")[0] if "-" in emp_id else "THN",
                # department can be null on this endpoint (e.g. Ramil's
                # record) — is_admin_department() already treats a
                # missing/blank department as "unknown, don't route to
                # ADMIN", consistent with prior behavior.
                "department": emp.get("department") or "",
            }
        except Exception as e:
            print("MASTER EMP ERROR:", e)

    # ── Today's attendance, keyed by prefixed emp_id ──
    try:
        log_records = requests.get(ATTENDANCE_LOGS_URL, timeout=10).json().get("data", [])
    except Exception as e:
        print("ATTENDANCE LOGS ERROR:", e)
        log_records = []

    today, now = date.today(), datetime.now().time()

    attendance_map: dict[str, dict] = {}
    for record in log_records:
        try:
            if not is_valid_employee_record(record):
                continue
            emp_id = build_prefixed_id(record.get("emp_no", ""), record.get("emp"))
            if not emp_id or emp_id in attendance_map:
                continue

            att_date_str = str(record.get("attendance_date", "")).strip()
            shift_name   = record.get("shift_name", "")
            if not is_in_todays_window(att_date_str, shift_name, today, now):
                continue

            time_in = record.get("time_in")
            attendance_map[emp_id] = {
                "time_in":    time_in if is_valid_checkin(time_in) else None,
                "shift_name": shift_name,
                "full_name":  str(record.get("full_name", "")).strip(),
            }
        except Exception as e:
            print("ATTENDANCE LOG ROW ERROR:", e)

    # ── Roster (employee_groupings) ──
    with db.engine.connect() as conn:
        groupings = conn.execute(sa_text("""
            SELECT emp_id, emp_no, full_name, emp, process, line_name, shift
            FROM frontend.employee_groupings
        """)).mappings().all()

    def is_admin_department(department) -> bool:
        """True if a known department value falls outside the allowed set."""
        dept = str(department or "").strip().lower()
        return bool(dept) and dept not in ALLOWED_DEPARTMENTS

    # Anyone who checked in today (attendance-logs) whose master-list
    # department disqualifies them — independent of roster assignment.
    # This is the authority for ADMIN card membership: it's based on who
    # actually showed up today with a non-allowed department, not on
    # who happens to be listed in employee_groupings.
    admin_ids: set[str] = {
        emp_id for emp_id, att in attendance_map.items()
        if is_admin_department((master_map.get(emp_id) or {}).get("department"))
    }

    def build_employee(g) -> dict:
        emp_id    = str(g["emp_id"]).strip().upper()
        lookup_id = build_prefixed_id(g["emp_no"] or emp_id, g["emp"]) or emp_id

        attendance = attendance_map.get(lookup_id)
        master     = master_map.get(lookup_id)

        time_in     = attendance["time_in"]    if attendance else None
        shift_name  = attendance["shift_name"] if attendance else (g["shift"] or "")
        status      = determine_roster_status(shift_name, time_in).lower()
        name        = g["full_name"] or (master["name"] if master else "") \
                      or (attendance["full_name"] if attendance else "") or "Unknown"

        return {
            "id": emp_id,
            "name": name,
            "agency": (master["agency"] if master else None) or (emp_id.split("-")[0] if "-" in emp_id else "THN"),
            "department": master["department"] if master else "",
            "section": g["process"] or "",
            "shift": shift_name,
            "time_in": time_in,
            "status": status,  # "present" | "late" | "absent"
        }

    if not groupings:
        return jsonify({
            "groups": [], "unassigned": [],
            "total_present": 0, "present_employees": [],
        })

    seen_lines: dict[str, list] = {}
    assigned_ids: set[str]      = set()
    for g in groupings:
        key = f"{(g['line_name'] or '').strip()}||{(g['shift'] or '').strip()}"
        seen_lines.setdefault(key, []).append(g)
        lookup_id = build_prefixed_id(g["emp_no"] or g["emp_id"], g["emp"]) or str(g["emp_id"]).strip().upper()
        assigned_ids.add(lookup_id)

    result_groups = []
    all_employees = []

    for key, line_groupings in seen_lines.items():
        line_name, shift = key.split("||", 1)
        members = []
        for g in line_groupings:
            lookup_id = build_prefixed_id(g["emp_no"] or str(g["emp_id"]).strip(), g["emp"]) \
                        or str(g["emp_id"]).strip().upper()
            if lookup_id in admin_ids:
                continue  # pulled out to the ADMIN card instead
            members.append(build_employee(g))

        all_employees.extend(members)
        result_groups.append({
            "id":        key,
            "line_name": line_name,
            "shift":     shift,
            "count":     len(members),
            "employees": members,
        })

    # Consolidated, non-transferable card for anyone who checked in today
    # with a department outside Quality/Technical/Assembly/Production —
    # whether or not they're on any roster line. One card per shift so it
    # still respects the shift filter.
    admin_by_shift: dict[str, list] = {}
    for emp_id in admin_ids:
        att    = attendance_map[emp_id]
        master = master_map.get(emp_id) or {}
        shift  = att["shift_name"] or "Unassigned Shift"

        admin_by_shift.setdefault(shift, []).append({
            "id": emp_id,
            "name": master.get("name") or att["full_name"] or "Unknown",
            "agency": master.get("agency") or (emp_id.split("-")[0] if "-" in emp_id else "THN"),
            "department": master.get("department", ""),
            "section": "ADMIN",
            "shift": shift,
            "time_in": att["time_in"],
            "status": determine_roster_status(shift, att["time_in"]).lower(),
        })

    for shift, admin_members in admin_by_shift.items():
        all_employees.extend(admin_members)
        result_groups.append({
            "id":        f"ADMIN||{shift}",
            "line_name": "ADMIN",
            "shift":     shift,
            "count":     len(admin_members),
            "employees": admin_members,
            "fixed":     True,
        })

    # Unassigned: checked in today, not on any roster, and not routed to ADMIN.
    unassigned = []
    for emp_id, att in attendance_map.items():
        if emp_id in assigned_ids or emp_id in admin_ids or att["time_in"] is None:
            continue
        master = master_map.get(emp_id)
        unassigned.append({
            "id": emp_id,
            "name": (master["name"] if master else att["full_name"]) or "Unknown",
            "agency": (master["agency"] if master else None) or (emp_id.split("-")[0] if "-" in emp_id else "THN"),
            "department": master["department"] if master else "",
            "section": "Unassigned",
            "shift": att["shift_name"],
            "time_in": att["time_in"],
            "status": determine_roster_status(att["shift_name"], att["time_in"]).lower(),
        })

    present_or_late = [e for e in all_employees + unassigned if e["status"] in ("present", "late")]

    return jsonify({
        "groups": result_groups,
        "unassigned": unassigned,
        "total_present": len(present_or_late),
        "present_employees": present_or_late,
    })


@data_bp.route("/api/data/<int:batch_id>")
@login_required
def data_by_batch(batch_id: int):
    try:
        with db.engine.connect() as conn:
            rows = conn.execute(sa_text("""
                SELECT s.emp_id, s.full_name, s.emp, s.process, s.line, s.shift,
                       g.emp_no AS emp_no
                FROM frontend.employee_snapshot_records s
                LEFT JOIN frontend.employee_groupings g ON g.emp_id = s.emp_id
                WHERE s.batch_id = :batch_id
                ORDER BY s.line, s.shift, s.full_name
            """), {"batch_id": batch_id}).mappings().all()

        time_in_map = _fetch_time_in_map()

        groups: dict[str, dict] = {}
        for r in rows:
            line_name = (r["line"] or "").strip()
            shift     = (r["shift"] or "").strip()
            key       = f"{line_name}|{shift}"
            if key not in groups:
                groups[key] = {
                    "id": len(groups) + 1, "name": f"{line_name} ({shift})",
                    "line_name": line_name, "shift": shift,
                    "plant": "Plant 2" if shift.upper().startswith("NIGHT") else "Plant 1",
                    "employees": [], "count": 0,
                }
            lookup_id = build_prefixed_id(r["emp_no"] or str(r["emp_id"]).strip(), r["emp"]) \
                        or str(r["emp_id"]).strip().upper()
            groups[key]["employees"].append({
                "id": r["emp_id"], "name": r["full_name"],
                "agency": r["emp"], "section": r["process"], "status": "present",
                "time_in": time_in_map.get(lookup_id),
            })
            groups[key]["count"] += 1

        return jsonify({"groups": list(groups.values()), "unassigned": []})

    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": str(e)}), 500


@data_bp.route("/api/dashboard-summary")
@login_required
def dashboard_summary():
    from datetime import datetime
    from routes.attendance import determine_status, is_valid_employee_record

    try:
        records = requests.get(ATTENDANCE_LOGS_URL, timeout=10).json().get("data", [])

        now, seen = datetime.now().time(), set()
        present = late = absent = pending = 0

        for record in records:
            if not is_valid_employee_record(record):
                continue

            emp_id = build_prefixed_id(record.get("emp_no", ""), record.get("emp"))
            att_date   = str(record.get("attendance_date", "")).strip()
            shift_name = record.get("shift_name", "")
            if not emp_id or emp_id in seen or not is_in_todays_window(att_date, shift_name, date.today(), now):
                continue
            seen.add(emp_id)

            status = determine_status(shift_name, record.get("time_in"), now)
            if status == "Present":  present += 1
            elif status == "Late":   late    += 1
            elif status == "Absent": absent  += 1
            else:                    pending += 1

        total    = present + late + absent + pending
        attended = present + late
        pct      = lambda val: round((val / total * 100), 2) if total > 0 else 0.0

        return jsonify({
            "present": attended, "late": late, "absent": absent, "pending": pending,
            "total": total, "attended": attended,
            "present_pct": pct(attended), "late_pct": pct(late),
            "absent_pct": pct(absent), "pending_pct": pct(pending),
            "attendance_rate": pct(attended),
            "as_of": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": str(e)}), 500


@data_bp.route("/api/agency-stats")
@login_required
def agency_stats():
    try:
        attendance_data = requests.get(ATTENDANCE_URL, timeout=10).json()
    except Exception:
        attendance_data = []

    today          = date.today()
    counts         = {"THN": 0, "CCI": 0, "NATCORP": 0, "EMIS": 0}
    seen: set[str] = set()

    for item in attendance_data:
        emp_id = str(item.get("emp_no", "")).strip()
        if not emp_id or emp_id in seen:
            continue
        if str(item.get("department", "")).strip().lower() not in ALLOWED_DEPARTMENTS:
            continue
        if parse_date(item.get("attendance_date", "")) != today:
            continue
        if not is_valid_checkin(item.get("check_in_time")):
            continue
        agency = emp_id.split("-")[0].strip().upper() if "-" in emp_id else ""
        if agency in counts:
            counts[agency] += 1
            seen.add(emp_id)

    return jsonify([{"agency": k, "present": v} for k, v in counts.items()])


@data_bp.route("/api/time")
def server_time():
    from datetime import datetime
    now = datetime.now()
    return jsonify({"time": now.strftime("%I:%M:%S %p"), "date": now.strftime("%Y-%m-%d")})