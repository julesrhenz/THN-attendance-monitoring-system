from flask import session, redirect, url_for, request, jsonify
from functools import wraps

# Roles allowed to access management pages/actions, vs. pure viewers.
STAFF_ROLES = {"Admin", "Supervisor"}


def login_required(f):
    """Block unauthenticated users."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("auth.home"))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    """
    Block non-Admin users from write/action endpoints.
    - API routes  → 403 JSON
    - Page routes → redirect to dashboard
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("auth.home"))
        if session.get("role") != "Admin":
            if request.path.startswith("/api/") or request.is_json:
                return jsonify({
                    "success": False,
                    "message": "Access denied. Admin role required.",
                }), 403
            return redirect(url_for("auth.dashboard"))
        return f(*args, **kwargs)
    return decorated


def staff_required(f):
    """
    Block plain Employee (view-only) accounts from management pages/actions
    that Admin and Supervisor are allowed to see (e.g. employee management,
    attendance log editing screens). Employees are redirected to the
    read-only dashboard instead.
    - API routes  → 403 JSON
    - Page routes → redirect to dashboard
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("auth.home"))
        if session.get("role") not in STAFF_ROLES:
            if request.path.startswith("/api/") or request.is_json:
                return jsonify({
                    "success": False,
                    "message": "Access denied. This view is restricted to staff accounts.",
                }), 403
            return redirect(url_for("auth.dashboard"))
        return f(*args, **kwargs)
    return decorated