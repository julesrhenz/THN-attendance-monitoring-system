from datetime import datetime, timedelta, timezone
from flask import Blueprint, request, jsonify, session
from sqlalchemy import text as sa_text
from io import BytesIO
from dateutil import parser as dateparser
from openpyxl import load_workbook
import traceback
import re

from routes.extensions import db
from routes.decorators import login_required, admin_required
from routes.shift_recalculator import recalculate_statuses_for_changed_employees

groupings_bp = Blueprint("groupings", __name__)

# ─── Constants ───────────────────────────────────────────────────
COLUMN_ALIASES = {
    "hc":         "hc",
    "last name":  "last_name",  "lastname":   "last_name",  "lname":      "last_name",
    "first name": "first_name", "firstname":  "first_name", "fname":      "first_name",
    "id no":      "employee_id","id no.":     "employee_id","id number":  "employee_id",
    "EMP NO.":    "employee_id","empid":      "employee_id",
    "full name":  "full_name",  "fullname":   "full_name",  "name":       "full_name",
    "date hired": "date_hired", "process":    "process",    "line":       "line",
    "emp":        "emp",        "emp.":       "emp",        "employment": "emp",
    "tenure":     "tenure",
}

KNOWN_AGENCIES = {"THN", "CCI", "NATCORP", "EMIS"}

AGENCY_PREFIX_MAP = {
    "THN":     "",
    "CCI":     "C-",
    "EMIS":    "E-",
    "NATCORP": "N-",
}

# Matches the `emp` integer FK used in employee_groupings, scanners, etc.
AGENCY_ID_MAP = {
    "THN":     1,
    "CCI":     2,
    "NATCORP": 3,
    "EMIS":    4,
}

TRACKED_FIELDS = {
    "shift":   "SHIFT",
    "process": "PROCESS",
    "line":    "LINE",
}

def normalize(value: object) -> str:
    if value is None:
        return ""
    s = str(value).strip()
    return "" if s.upper() in ("N/A", "NA", "-", "NONE", "NULL") else s


def clean(value: object) -> str | None:
    if value is None:
        return None
    s = str(value).strip()
    return None if s.upper() in ("", "N/A", "NA", "-", "NONE") else s


def safe_date(value: object):
    if not value:
        return None
    try:
        return dateparser.parse(str(value)).date()
    except Exception:
        return None


# ─── Excel helpers ────────────────────────────────────────────────
def parse_sheet_name(sheet_name: str) -> dict:
    raw = sheet_name.strip().upper()
    if "NIGHT" in raw:
        return {"line_id": re.sub(r'\s*NIGHT$', '', raw).strip(), "shift": "Night Shift"}
    if "DAY" in raw:
        return {"line_id": re.sub(r'\s*(2ND\s+)?DAY$', '', raw).strip(), "shift": "Day Shift"}
    raise ValueError(f"Sheet '{sheet_name}' skipped — name must contain 'DAY' or 'NIGHT'.")


def extract_sub_tables(ws) -> list:
    all_rows = list(ws.iter_rows(values_only=True))
    n        = len(all_rows)

    global_header: list | None = None
    for row in all_rows:
        cells = [str(c).strip().lower() for c in row if c is not None and str(c).strip()]
        if "last name" in cells or "first name" in cells:
            global_header = list(row)
            break

    agency_starts: list[tuple[int, str]] = []
    for i, row in enumerate(all_rows):
        if not row:
            continue
        first = next(
            (str(c).strip().upper() for c in row if c is not None and str(c).strip()), None
        )
        if first in KNOWN_AGENCIES:
            agency_starts.append((i, first))

    if not agency_starts:
        return []

    blocks = []
    for idx, (start_row, agency) in enumerate(agency_starts):
        end_row    = agency_starts[idx + 1][0] if idx + 1 < len(agency_starts) else n
        header_row: list | None = None
        data_rows: list         = []

        for r in range(start_row + 1, end_row):
            row = all_rows[r]
            if not row or all(c is None or str(c).strip() == "" for c in row):
                continue
            cells = [str(c).strip().lower() for c in row if c is not None and str(c).strip()]
            if "last name" in cells or "first name" in cells:
                header_row = list(row)
                continue
            data_rows.append(list(row))

        final_header = header_row or global_header
        if final_header and data_rows:
            blocks.append({"agency": agency, "header_row": final_header, "data_rows": data_rows})

    return blocks

def normalize_id(value: object) -> str:
    """
    Excel numeric ID cells are read by openpyxl as float (1222 -> 1222.0),
    so a naive str() on the cell value stores "1222.0" while every other
    system (attendance-logs API, employee master) uses "1222". Strip a
    trailing ".0" off a purely-numeric string so IDs match across sources.
    """
    s = str(value or "").strip()
    if s.endswith(".0") and s[:-2].isdigit():
        return s[:-2]
    return s

def parse_block(block: dict, line_id: str, shift: str, sheet_name: str) -> tuple:
    header   = block.get("header_row", [])
    agency   = block.get("agency", "UNKNOWN")
    warnings: list[str] = []

    if not header:
        warnings.append(f"Sheet '{sheet_name}' → Agency '{agency}': empty header, skipped.")
        return [], warnings

    col_map: dict[str, int] = {}

    for col_idx, cell in enumerate(header):
        if cell is None:
            continue
        key = str(cell).strip().lower()
        if key in COLUMN_ALIASES:
            col_map[COLUMN_ALIASES[key]] = col_idx

    if "employee_id" not in col_map:
        for i, cell in enumerate(header):
            if cell is None:
                continue
            val = str(cell).strip().lower()
            if "last" in val:                                          col_map.setdefault("last_name",   i)
            elif "first" in val:                                       col_map.setdefault("first_name",  i)
            elif "emp no" in val or "emp. no" in val or "no." in val: col_map.setdefault("employee_id", i)
            elif "full" in val:                                        col_map.setdefault("full_name",   i)
            elif "date" in val or "hired" in val:                      col_map.setdefault("date_hired",  i)
            elif "process" in val:                                     col_map.setdefault("process",     i)
            elif "tenure" in val or val in ("ten.", "ten"):            col_map.setdefault("tenure",      i)
            elif "line" in val:                                        col_map.setdefault("line",        i)
            elif val in ("emp", "emp."):                               col_map.setdefault("emp",         i)
            elif val in ("hc", "h.c", "head"):                        col_map.setdefault("hc",          i)

    if "employee_id" not in col_map:
        for field, pos in [
            ("hc", 0), ("last_name", 1), ("first_name", 2), ("employee_id", 3),
            ("full_name", 4), ("date_hired", 5), ("process", 6),
            ("line", 7), ("emp", 8), ("tenure", 9),
        ]:
            col_map.setdefault(field, pos)

    employees: list[dict] = []

    for raw_row in block.get("data_rows", []):
        if not raw_row:
            continue

        def get(field: str, row: list = raw_row) -> object:
            idx = col_map.get(field)
            return None if idx is None or idx >= len(row) else row[idx]

        def get_text(field: str) -> str:
            val = get(field)
            return "" if val is None else str(val).strip()

        emp_id_raw = normalize_id(get_text("employee_id"))
        if not emp_id_raw or emp_id_raw.lower() in ("none", "nan", "-", "n/a", "emp no.", "emp no"):
            continue

        agency_code = get_text("emp") or agency
        prefix      = AGENCY_PREFIX_MAP.get(agency_code.upper(), f"{agency_code}-")
        emp_id      = f"{prefix}{emp_id_raw}"
        last        = get_text("last_name")
        first       = get_text("first_name")
        full        = get_text("full_name") or f"{first} {last}".strip()

        tenure_raw = get("tenure")
        tenure: float | None = None
        if tenure_raw not in ("", None):
            if isinstance(tenure_raw, (int, float)):
                tenure = float(tenure_raw)
            else:
                try:
                    tenure = float(str(tenure_raw).strip())
                except ValueError:
                    tenure = None

        employees.append({
            "employee_id": emp_id.strip().upper(),
            "emp_no":      emp_id_raw,             # raw scanner ID, before agency prefix
            "last_name":   last,   "first_name": first,
            "full_name":   full,   "name":       full,
            "agency":      agency_code,
            "section":     get_text("process") or get_text("section"),
            "sheet_name":  sheet_name,
            "line_id":     str(line_id).strip(),
            "shift":       str(shift).strip(),
            "hc":          get_text("hc"),
            "date_hired":  get_text("date_hired"),
            "process":     normalize(get_text("process")),
            # The parent grouping key MUST come from the workbook sheet tab
            # name (parsed by parse_sheet_name into line_id above) — never
            # from an inner "line" cell in the row data. That inner cell is
            # a sub-line the employee belongs to *within* this sheet, not
            # the top-level line/tab itself, and must not overwrite it.
            "line":        str(line_id).strip(),
            "sub_line":    normalize(get_text("line")),
            "emp":         get_text("emp"),
            "tenure":      tenure,

        })

    return employees, warnings


def detect_movements(conn, batch_id: int, all_employees: list) -> tuple:
    """
    Compares this import's employee data against the previous batch's
    snapshot to detect field-level changes (shift/process/line), logging
    each as a row in employee_movements.

    Returns:
        (movement_count, shift_changed) where shift_changed is a list of
        dicts — {"emp_id", "old_shift", "new_shift"} — for every employee
        whose shift specifically changed this import. That list is used
        by import_grouping() to trigger attendance status recalculation
        on the external attendance server, since a shift change can make
        previously-computed time_in_status/time_out_status/shift_name on
        existing attendance_logs rows stale.
    """
    prev_batch = conn.execute(sa_text("""
        SELECT id FROM frontend.import_batches
        WHERE id < :current_id ORDER BY id DESC LIMIT 1
    """), {"current_id": batch_id}).fetchone()

    if not prev_batch:
        return 0, []

    prev_batch_id = prev_batch[0]
    prev_rows     = conn.execute(sa_text("""
        SELECT emp_id, full_name, shift, process, line
        FROM frontend.employee_snapshot_records
        WHERE batch_id = :batch_id
    """), {"batch_id": prev_batch_id}).fetchall()

    prev_map = {
        normalize(r[0]).upper(): {
            "full_name": r[1] or "",
            "shift":     normalize(r[2]),
            "process":   normalize(r[3]),
            "line":      normalize(r[4]),
        }
        for r in prev_rows
    }

    movement_count = 0
    shift_changed: list[dict] = []

    for emp in all_employees:
        emp_id    = normalize(emp.get("employee_id", "")).upper()
        prev_data = prev_map.get(emp_id)
        if not emp_id or not prev_data:
            continue

        for field, field_name in TRACKED_FIELDS.items():
            curr_val = normalize(emp.get(field, ""))
            prev_val = prev_data.get(field, "")
            if not curr_val or not prev_val or curr_val.upper() == prev_val.upper():
                continue

            conn.execute(sa_text("""
                INSERT INTO frontend.employee_movements
                    (emp_id, full_name, field_name, old_value, new_value,
                     from_batch_id, to_batch_id, detected_at)
                VALUES
                    (:emp_id, :full_name, :field_name, :old_value, :new_value,
                     :from_batch_id, :to_batch_id, NOW())
            """), {
                "emp_id": emp_id, "full_name": emp.get("full_name", ""),
                "field_name": field_name, "old_value": prev_val, "new_value": curr_val,
                "from_batch_id": prev_batch_id, "to_batch_id": batch_id,
            })
            movement_count += 1

            if field == "shift":
                shift_changed.append({
                    "emp_id":    emp_id,
                    "old_shift": prev_val,
                    "new_shift": curr_val,
                })

    return movement_count, shift_changed


def fetch_current_state(conn) -> dict:
    """
    Builds the complete, global set of line/shift groups from the LIVE
    employee_groupings table — not the batch that was just imported.

    Because every employee row is keyed by emp_id and carries its own
    line_name/line/shift, grouping this table at query time is what makes
    the merge automatic:
      - Sheets from a previous import that weren't touched by this import
        simply remain in the result set (their employee rows still exist).
      - A sheet name that reappears in a new import isn't duplicated,
        because each employee within it was just UPSERTed via
        ON CONFLICT (emp_id) DO UPDATE — so the group it's collected into
        here reflects the new data in place.

    This replaces "return the batch" with "return the world" as the
    contract of the import endpoint.
    """
    rows = conn.execute(sa_text("""
        SELECT emp_id, emp_no, full_name, line_name, line, shift, process, tenure, date_hired
        FROM frontend.employee_groupings
        ORDER BY line_name, shift, last_name, first_name
    """)).mappings().all()

    groups_by_key: dict[str, dict] = {}
    unassigned: list[dict] = []

    for r in rows:
        emp_payload = {
            "id":      r["emp_id"],
            "name":    r["full_name"],
            "section": r["process"] or "",
        }

        line_name = clean(r["line_name"])
        shift     = clean(r["shift"])

        if not line_name or not shift:
            unassigned.append(emp_payload)
            continue

        key = f"{line_name}||{shift}"
        if key not in groups_by_key:
            groups_by_key[key] = {
                "id":        key,          # stable across imports — doubles as merge key
                "line_name": line_name,
                "line":      r["line"],
                "shift":     shift,
                "employees": [],
            }
        groups_by_key[key]["employees"].append(emp_payload)

    groups = list(groups_by_key.values())
    for g in groups:
        g["count"] = len(g["employees"])

    return {"groups": groups, "unassigned": unassigned}
# ─── Routes ──────────────────────────────────────────────────────
@groupings_bp.route("/api/import-grouping", methods=["POST"])
@admin_required
def import_grouping():
    try:
        if "file" not in request.files:
            return jsonify({"success": False, "message": "No file uploaded."}), 400

        file = request.files["file"]
        if not file.filename or not file.filename.lower().endswith((".xlsx", ".xls")):
            return jsonify({"success": False, "message": "Please upload a valid Excel file."}), 400

        wb            = load_workbook(BytesIO(file.read()), data_only=True)
        result_lines  = []
        all_warnings  = []
        sheet_errors  = []
        all_employees = []

        for sheet_name in wb.sheetnames:
            try:
                meta = parse_sheet_name(sheet_name)
            except ValueError as e:
                sheet_errors.append(str(e))
                continue

            try:
                blocks = extract_sub_tables(wb[sheet_name])
            except Exception as e:
                sheet_errors.append(f"Sheet '{sheet_name}': {str(e)}")
                continue

            if not blocks:
                all_warnings.append(f"Sheet '{sheet_name}': no data found.")
                continue

            sheet_employees: list = []
            for block in blocks:
                try:
                    emps, warns = parse_block(block, meta["line_id"], meta["shift"], sheet_name)
                    sheet_employees.extend(emps)
                    all_warnings.extend(warns)
                except Exception as e:
                    all_warnings.append(f"Block error in '{sheet_name}': {str(e)}")

            all_employees.extend(sheet_employees)
            result_lines.append({
                "line_name":      f"{meta['line_id']} — {meta['shift']}",
                "line_id":        meta["line_id"],
                "shift":          meta["shift"],
                "sheet_name":     sheet_name,
                "employee_count": len(sheet_employees),
                "employees":      sheet_employees,
            })

        if not result_lines and sheet_errors:
            return jsonify({
                "success": False,
                "message": "No valid sheets found.\n\n" + "\n".join(sheet_errors),
            }), 400

        movements_count = 0
        shift_changed: list[dict] = []
        try:
            with db.engine.begin() as conn:
                conn.execute(sa_text("SELECT pg_advisory_xact_lock(:key)"), {"key": 4815162342})
                conn.execute(sa_text("ALTER TABLE frontend.import_batches ADD COLUMN IF NOT EXISTS schedule_effective_at TIMESTAMP"))
                uploaded_at = datetime.now(timezone(timedelta(hours=8))).replace(tzinfo=None)
                raw_date = request.form.get("schedule_effective_date", "").strip()
                schedule_at = datetime.strptime(raw_date, "%Y-%m-%d") if raw_date else uploaded_at.replace(hour=0, minute=0, second=0, microsecond=0)
                batch    = conn.execute(sa_text("""
                    INSERT INTO frontend.import_batches
                        (filename, imported_by, total_lines, total_employees, effective_at, schedule_effective_at)
                    VALUES (:filename, :imported_by, :total_lines, :total_employees, :uploaded_at, :schedule_at)
                    RETURNING id
                """), {
                    "uploaded_at": uploaded_at, "schedule_at": schedule_at,
                    "filename":        file.filename,
                    "imported_by":     session.get("username", "system"),
                    "total_lines":     len(result_lines),
                    "total_employees": len(all_employees),
                })
                batch_id: int = batch.fetchone()[0]

                for emp in all_employees:
                    emp_id        = str(emp.get("employee_id", "")).strip().upper()
                    date_hired    = safe_date(emp.get("date_hired"))
                    process_value = clean(emp.get("process"))
                    line_value    = clean(emp.get("line"))
                    shift_value   = clean(emp.get("shift"))
                    emp_str       = str(emp.get("emp", "")).strip().upper()
                    emp_int       = AGENCY_ID_MAP.get(emp_str)  # integer FK for employee_groupings

                    prev = conn.execute(sa_text(
                        "SELECT process, line, shift FROM frontend.employee_groupings WHERE emp_id = :id"
                    ), {"id": emp_id}).fetchone()
                    if prev:
                        process_value = process_value or prev[0]
                        line_value    = line_value    or prev[1]
                        shift_value   = shift_value   or prev[2]

                    params = {
                        "batch_id": batch_id, "emp_id": emp_id,
                        "emp":       emp_int,           # integer FK
                        "full_name": emp.get("full_name", ""),
                        "line":      line_value,    "shift":     shift_value,
                        "process":   process_value, "tenure":    emp.get("tenure"),
                        "date_hired": date_hired,
                    }

                    conn.execute(sa_text("""
                        INSERT INTO frontend.employee_snapshot_records
                            (batch_id, emp_id, emp, full_name, line, shift, process, tenure, date_hired)
                        VALUES
                            (:batch_id, :emp_id, :emp, :full_name, :line, :shift, :process, :tenure, :date_hired)
                        ON CONFLICT (batch_id, emp_id) DO UPDATE SET
                            full_name = EXCLUDED.full_name, line      = EXCLUDED.line,
                            shift     = EXCLUDED.shift,     process   = EXCLUDED.process,
                            tenure    = EXCLUDED.tenure,    date_hired= EXCLUDED.date_hired
                    """), params)

                    conn.execute(sa_text("""
                        INSERT INTO frontend.employee_groupings (
                            emp_id, emp_no, emp, last_name, first_name, full_name,
                            line_name, shift, process, line, date_hired, tenure, updated_at
                        ) VALUES (
                            :emp_id, :emp_no, :emp, :last_name, :first_name, :full_name,
                            :line_name, :shift, :process, :line, :date_hired, :tenure, NOW()
                        )
                        ON CONFLICT (emp_id) DO UPDATE SET
                            emp_no     = EXCLUDED.emp_no,
                            emp        = EXCLUDED.emp,
                            last_name  = EXCLUDED.last_name,
                            first_name = EXCLUDED.first_name,
                            full_name  = EXCLUDED.full_name,
                            line_name  = EXCLUDED.line_name,
                            shift      = EXCLUDED.shift,
                            process    = EXCLUDED.process,
                            line       = EXCLUDED.line,
                            date_hired = EXCLUDED.date_hired,
                            tenure     = EXCLUDED.tenure,
                            updated_at = NOW()
                    """), {
                        **params,
                        "emp_no":     emp.get("emp_no",     ""),
                        "last_name":  emp.get("last_name",  ""),
                        "first_name": emp.get("first_name", ""),
                        "line_name": emp.get("sheet_name", "")
                    })

                movements_count, shift_changed = detect_movements(conn, batch_id, all_employees)

                # Recalculate attendance_logs statuses for anyone whose shift
                # changed this import. backend.attendance_logs lives in the
                # same Postgres database as employee_groupings (just a
                # different schema), so this runs on the same connection,
                # inside the same transaction as the import itself — if it
                # fails, the whole import rolls back together with it,
                # rather than leaving stale statuses silently behind.
                rows_recalculated = recalculate_statuses_for_changed_employees(conn, [{"emp_id": str(e["employee_id"]).strip().upper()} for e in all_employees], effective_at=schedule_at)

                full_state = fetch_current_state(conn)

        except Exception as e:
            traceback.print_exc()
            return jsonify({"success": False, "message": f"Database error: {str(e)}"}), 500

        return jsonify({
            "success": True,
            "lines":        full_state["groups"],     # global, merged, cumulative state
            "unassigned":   full_state["unassigned"],
            "imported_sheets": result_lines,           # just this batch, for warnings/receipt UI
            "batch_id": batch_id,
            "warnings": all_warnings, "errors": sheet_errors,
            "movements_found": movements_count,
            "shift_changes_recalculated": rows_recalculated,
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": f"Server error: {str(e)}"}), 500


@groupings_bp.route("/api/import-batches")
@login_required
def import_batches():
    with db.engine.connect() as conn:
        rows = conn.execute(sa_text("""
            SELECT id, filename, imported_at
            FROM frontend.import_batches
            ORDER BY imported_at DESC
        """)).mappings().all()
    return jsonify([{
        "id": r["id"], "filename": r["filename"], "imported_at": str(r["imported_at"]),
    } for r in rows])


@groupings_bp.route("/api/manual-move-employee", methods=["POST"])
@admin_required
def manual_move_employee():
    try:
        data   = request.get_json(force=True, silent=True) or {}
        emp_id = str(data.get("emp_id", "")).strip().upper()

        if not emp_id:
            return jsonify({"success": False, "message": "Employee ID is required."}), 400

        with db.engine.begin() as conn:
            existing = conn.execute(sa_text("""
                SELECT full_name, line, line_name, shift, process
                FROM frontend.employee_groupings WHERE emp_id = :emp_id
            """), {"emp_id": emp_id}).fetchone()

            if not existing:
                return jsonify({"success": False, "message": "Employee not found."}), 404

            full_name, old_line, old_line_name, old_shift, old_process = existing

            final = {
                "line":      data.get("new_line")      or old_line,
                "line_name": data.get("new_line_name")  or old_line_name,
                "shift":     data.get("new_shift")     or old_shift,
                "process":   data.get("new_process")   or old_process,
            }

            conn.execute(sa_text("""
                UPDATE frontend.employee_groupings
                SET
                    line = :line,
                    line_name = :line_name,
                    shift = :shift,
                    process = :process,
                    updated_at = NOW()
                WHERE emp_id = :emp_id
            """), {**final, "emp_id": emp_id})

            field_map = {
                "LINE":      (old_line,      final["line"]),
                "LINE_NAME": (old_line_name, final["line_name"]),
                "SHIFT":     (old_shift,     final["shift"]),
                "PROCESS":   (old_process,   final["process"]),
            }
            for field_name, (old_val, new_val) in field_map.items():
                if old_val == new_val:
                    continue
                conn.execute(sa_text("""
                    INSERT INTO frontend.employee_movements
                        (emp_id, full_name, field_name, old_value, new_value, detected_at)
                    VALUES
                        (:emp_id, :full_name, :field_name, :old_value, :new_value, (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila'))
                """), {
                    "emp_id": emp_id, "full_name": full_name,
                    "field_name": field_name, "old_value": old_val, "new_value": new_val,
                })

            # A manual line move can also change an employee's shift, so this
            # needs the same recalculation as a bulk import gets. Runs on the
            # same connection/transaction as the update above.
            if old_shift != final["shift"]:
                recalculate_statuses_for_changed_employees(conn, [{
                    "emp_id": emp_id, "old_shift": old_shift, "new_shift": final["shift"],
                }])

        return jsonify({"success": True, "employee": {"emp_id": emp_id, "full_name": full_name, **final}})

    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": str(e)}), 500

@groupings_bp.route("/api/all-lines")
@login_required
def all_lines():
    try:
        with db.engine.connect() as conn:
            rows = conn.execute(sa_text("""
                SELECT DISTINCT line_name, line, shift
                FROM frontend.employee_groupings
                WHERE line IS NOT NULL AND line != ''
                ORDER BY line_name, line
            """)).mappings().all()

        return jsonify([{
            "line_name": r["line_name"], "line": r["line"], "shift": r["shift"],
        } for r in rows])

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@groupings_bp.route("/api/employee-history/<emp_id>")
@login_required
def employee_history(emp_id: str):
    try:
        with db.engine.connect() as conn:
            rows = conn.execute(sa_text("""
                SELECT
                    m.field_name, m.old_value, m.new_value,
                    b_from.filename AS from_file, b_from.imported_at AS from_date,
                    b_to.filename   AS to_file,   b_to.imported_at   AS to_date,
                    m.detected_at
                FROM frontend.employee_movements m
                LEFT JOIN frontend.import_batches b_from ON b_from.id = m.from_batch_id
                LEFT JOIN frontend.import_batches b_to   ON b_to.id   = m.to_batch_id
                WHERE m.emp_id = :emp_id
                ORDER BY m.detected_at DESC
            """), {"emp_id": emp_id}).fetchall()

        return jsonify([{
            "field":       r[0], "from_value": r[1], "to_value":   r[2],
            "from_file":   r[3], "from_date":  str(r[4]) if r[4] else None,
            "to_file":     r[5], "to_date":    str(r[6]) if r[6] else None,
            "detected_at": str(r[7]),
        } for r in rows])

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@groupings_bp.route("/api/movements-summary")
@login_required
def movements_summary():
    try:
        with db.engine.connect() as conn:
            latest = conn.execute(sa_text("""
                SELECT id, filename, imported_at
                FROM frontend.import_batches
                ORDER BY id DESC LIMIT 1
            """)).fetchone()

            if not latest:
                return jsonify({"movements": [], "batch": None})

            rows = conn.execute(sa_text("""
                SELECT m.emp_id, m.full_name, m.field_name,
                       m.old_value, m.new_value, m.detected_at
                FROM frontend.employee_movements m
                WHERE m.to_batch_id = :bid
                ORDER BY m.full_name
            """), {"bid": latest[0]}).fetchall()

        return jsonify({
            "batch": {"id": latest[0], "filename": latest[1], "imported_at": str(latest[2])},
            "movements": [{
                "emp_id": r[0], "full_name": r[1], "field": r[2],
                "from_value": r[3], "to_value": r[4], "detected_at": str(r[5]),
            } for r in rows],
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500