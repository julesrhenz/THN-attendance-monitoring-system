from routes.attendance_history import record_shift_change
from flask import Blueprint, request, jsonify
import traceback
from sqlalchemy import text as sa_text

from routes.decorators import login_required, admin_required
from routes.extensions import db

employees_bp = Blueprint("employees", __name__)

AGENCY_ID_MAP = {"THN": 1, "CCI": 2, "NATCORP": 3, "EMIS": 4}


@employees_bp.route("/api/employees")
@login_required
def api_employees():
    try:
        with db.engine.connect() as conn:
            rows = conn.execute(sa_text("""
                SELECT emp_id, emp_no, emp, last_name, first_name, full_name,
                       line_name, line, shift, process, date_hired, tenure, updated_at
                FROM frontend.employee_groupings
                ORDER BY last_name, first_name
            """)).mappings().all()
        return jsonify([dict(r) | {"updated_at": str(r["updated_at"]) if r["updated_at"] else None,
                                    "date_hired": str(r["date_hired"]) if r["date_hired"] else None}
                        for r in rows])
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@employees_bp.route("/api/employees/add", methods=["POST"])
@admin_required
def api_employees_add():
    try:
        payload = request.json or {}
        emp_no = str(payload.get("emp_no", "")).strip()
        agency_prefix = emp_no.split("-")[0].upper() if "-" in emp_no else "THN"

        with db.engine.begin() as conn:
            conn.execute(sa_text("""
                INSERT INTO frontend.employee_groupings
                    (emp_id, emp_no, emp, last_name, first_name, full_name,
                     line_name, line, shift, process, date_hired, tenure, updated_at)
                VALUES
                    (:emp_id, :emp_no, :emp, :last_name, :first_name, :full_name,
                     :line_name, :line, :shift, :process, :date_hired, :tenure, NOW())
                ON CONFLICT (emp_id) DO NOTHING
            """), {
                "emp_id": payload.get("emp_id", emp_no).strip().upper(),
                "emp_no": emp_no,
                "emp": AGENCY_ID_MAP.get(agency_prefix),
                "last_name": payload.get("last_name", ""),
                "first_name": payload.get("first_name", ""),
                "full_name": payload.get("full_name", ""),
                "line_name": payload.get("line_name"),
                "line": payload.get("line"),
                "shift": payload.get("shift"),
                "process": payload.get("process"),
                "date_hired": payload.get("date_hired"),
                "tenure": payload.get("tenure"),
            })
        return jsonify({"success": True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": str(e)}), 500


@employees_bp.route("/api/employees/update", methods=["PUT"])
@admin_required
def api_employees_update():
    try:
        payload = request.json or {}
        emp_id = str(payload.get("emp_id", "")).strip().upper()
        if not emp_id:
            return jsonify({"success": False, "message": "emp_id is required."}), 400

        with db.engine.begin() as conn:
            conn.execute(sa_text("SELECT pg_advisory_xact_lock(:key)"), {"key":4815162342})
            old_row = conn.execute(sa_text("SELECT shift, full_name FROM frontend.employee_groupings WHERE emp_id=:id FOR UPDATE"), {"id":emp_id}).mappings().first()
            if not old_row:
                return jsonify({"success":False, "message":"Employee not found."}),404
            conn.execute(sa_text("""
                UPDATE frontend.employee_groupings
                SET last_name = :last_name, first_name = :first_name, full_name = :full_name,
                    line_name = :line_name, line = :line, shift = :shift,
                    process = :process, date_hired = :date_hired, tenure = :tenure,
                    updated_at = NOW()
                WHERE emp_id = :emp_id
            """), {**payload, "emp_id": emp_id})
            record_shift_change(conn, emp_id, old_row["shift"], payload.get("shift"), payload.get("full_name"))
        return jsonify({"success": True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": str(e)}), 500


@employees_bp.route("/api/employees/delete/<emp_id>", methods=["DELETE"])
@admin_required
def api_employees_delete(emp_id: str):
    try:
        with db.engine.begin() as conn:
            result = conn.execute(sa_text("""
                DELETE FROM frontend.employee_groupings WHERE emp_id = :emp_id
            """), {"emp_id": emp_id.strip().upper()})
        if result.rowcount == 0:
            return jsonify({"success": False, "message": "Employee not found."}), 404
        return jsonify({"success": True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "message": str(e)}), 500


@employees_bp.route("/api/users")
@login_required
def get_users():
    try:
        with db.engine.connect() as conn:
            rows = conn.execute(sa_text("""
                SELECT username, first_name, last_name, roles
                FROM frontend.users ORDER BY first_name
            """)).fetchall()
        return jsonify([{
            "username": r[0], "first_name": r[1],
            "last_name": r[2], "roles": r[3],
        } for r in rows])
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@employees_bp.route("/api/debug-users-schema")
@admin_required
def debug_users_schema():
    try:
        with db.engine.connect() as conn:
            rows = conn.execute(sa_text(
                "SELECT column_name, data_type "
                "FROM information_schema.columns "
                "WHERE table_schema = 'frontend' AND table_name = 'users' "
                "ORDER BY ordinal_position"
            )).fetchall()
        return jsonify([{"column": r[0], "type": r[1]} for r in rows])
    except Exception as e:
        return jsonify({"error": str(e)}), 500