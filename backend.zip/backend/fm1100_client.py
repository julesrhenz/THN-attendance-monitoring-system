"""
fm1100_client.py
-----------------
Live socket client for the David-Link FM1100 scanner.

WHAT'S SOLID:
    - Record decoding (_decode_record) and stream framing (poll/_drain_socket).
    - This part is reverse-engineered from an actual captured log and matches
      your existing AttendanceRecord shape (machine_id, employee_id,
      timestamp, record_type, new_record_flag, cur_idx, total_cnt).

WHAT'S NOT SOLID / TODO -- I have no data on these, do not trust them:
    - connect(): the login/handshake byte sequence. I don't know what this
      device expects on connect since it doesn't speak standard zkprotocol.
      Currently this just opens a TCP socket and reads whatever comes back
      -- no login packet is sent. If the device requires a login command
      before it'll talk, records will simply never arrive.
    - download_all_records()/download_all_new_records(): the command bytes
      to *request* a download. Currently these are empty stubs. Until you
      (or a packet capture of the vendor's own software talking to the
      device) tell me what bytes trigger a download, this client can only
      passively listen -- it can't proactively ask the device for records.
    - No ACK/keepalive handling. If the protocol expects the client to ack
      each record (many zkteco-alikes do), you'll likely see the device
      stall or resend after the first few records without one.

RECOMMENDED NEXT STEP:
    Get Wireshark (or similar) on the same subnet as the FM1100 while the
    vendor's own Windows software connects to it and pulls records. Filter
    on the device IP/port and export the raw bytes of:
      1. The first few packets right after TCP connect (login/handshake).
      2. The packet sent right before records start streaming back
         (download trigger).
      3. Any short packets sent *from* the client in between records
         (likely ACKs).
    Paste those bytes here and I can wire real connect()/download_all_*()
    logic instead of these stubs.
"""

import socket
import threading
import queue
from datetime import datetime
from dataclasses import dataclass

RECORD_SIZE = 28


@dataclass
class AttendanceRecord:
    machine_id: int
    employee_id: int
    timestamp: datetime
    record_type: int
    new_record_flag: int
    cur_idx: int
    total_cnt: int
    source_format: str = "fm1100"


def _decode_zk_time(v: int) -> datetime:
    second = v % 60; v //= 60
    minute = v % 60; v //= 60
    hour   = v % 24; v //= 24
    day    = v % 31 + 1; v //= 31
    month  = v % 12 + 1; v //= 12
    year   = v + 2000
    return datetime(year, month, day, hour, minute, second)


def _decode_record(b: bytes) -> AttendanceRecord:
    if len(b) != RECORD_SIZE:
        raise ValueError(f"expected {RECORD_SIZE} bytes, got {len(b)}")

    machine_id      = int.from_bytes(b[0:8], "little")
    employee_id     = int.from_bytes(b[8:10], "big")
    ts_raw          = int.from_bytes(b[10:14], "big")
    record_type     = b[14]
    new_record_flag = b[15]
    cur_idx         = int.from_bytes(b[20:22], "little")
    total_cnt       = int.from_bytes(b[24:28], "little")

    return AttendanceRecord(
        machine_id=machine_id,
        employee_id=employee_id,
        timestamp=_decode_zk_time(ts_raw),
        record_type=record_type,
        new_record_flag=new_record_flag,
        cur_idx=cur_idx,
        total_cnt=total_cnt,
    )


class FM1100Client:
    """
    Interface deliberately mirrors AnvizEP300 (connect/poll/
    download_all_records/download_all_new_records/get_record_status) so it
    can drop into scanner_attendance_sync.sync_scanner() with minimal
    changes. See module docstring -- connect()/download_all_*() are TODO
    stubs until the handshake protocol is known.
    """

    def __init__(self):
        self._sock: socket.socket | None = None
        self._buf = bytearray()
        self._records: "queue.Queue[AttendanceRecord]" = queue.Queue()
        self._reader_thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._dev_type_flags = {}  # kept for interface parity with AnvizEP300

    def start(self):
        """No-op, kept for interface parity with AnvizEP300.start()."""
        pass

    def connect(self, ip: str, port: int, timeout: float = 5.0) -> int:
        self._sock = socket.create_connection((ip, port), timeout=timeout)
        self._sock.settimeout(1.0)

        # TODO: send actual login/handshake bytes here once known.
        # e.g. self._sock.sendall(LOGIN_PACKET)

        self._stop.clear()
        self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
        self._reader_thread.start()
        return 0  # matches AnvizEP300's "0 on success" convention

    def _reader_loop(self):
        assert self._sock is not None, "reader loop started before connect()"
        while not self._stop.is_set():
            try:
                chunk = self._sock.recv(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            if not chunk:
                break
            self._buf.extend(chunk)
            self._drain_buffer()

    def _drain_buffer(self):
        """Slice off complete 28-byte records. Assumes records arrive
        back-to-back with no extra wrapper/delimiter, matching the sample
        log. If the live stream turns out to have a header/length-prefix
        per packet (likely, given "Message=1 Length=28 Dev=1" in your log
        was probably printed by whatever tool captured it, not sent on the
        wire), this will need a small tweak -- paste a live hex capture
        here and I'll adjust the framing."""
        while len(self._buf) >= RECORD_SIZE:
            raw = bytes(self._buf[:RECORD_SIZE])
            del self._buf[:RECORD_SIZE]
            try:
                self._records.put(_decode_record(raw))
            except ValueError:
                # malformed/misaligned -- drop one byte and try to resync
                del self._buf[:1]

    def poll(self, timeout_seconds: float = 3.0) -> list:
        """Drains whatever decoded records have arrived within the window.
        Matches AnvizEP300.poll()'s return-a-list-of-records behavior."""
        import time
        records = []
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            try:
                records.append(self._records.get(timeout=0.1))
            except queue.Empty:
                continue
        return records

    def get_record_status(self, dev_idx: int):
        """TODO: unknown wire format for a status query. Stubbed."""
        return None

    def download_all_records(self, dev_idx: int) -> int:
        """TODO: send the real 'download all' command bytes here once
        captured. Currently a no-op -- the device will only send data if
        it's already streaming unprompted (some devices do push records
        on their own after connect)."""
        return 0

    def download_all_new_records(self, dev_idx: int) -> int:
        """TODO: same as above, for 'new records only'."""
        return 0

    def stop(self):
        self._stop.set()
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass
        if self._reader_thread:
            self._reader_thread.join(timeout=2)