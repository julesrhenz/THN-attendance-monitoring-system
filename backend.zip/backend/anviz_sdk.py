"""
anviz_sdk.py

Thin, reusable wrapper around Anviz's tc-b_new_sdk.dll (CrossChex TCP/IP SDK),
mirroring what python-zk's ZK class provides for ZKTeco devices, so it can be
dropped into sync_bio.py's per-scanner worker with minimal changes.

Usage:
    from anviz_sdk import AnvizSDK

    sdk = AnvizSDK(dll_path="C:/path/to/tc-b_new_sdk.dll")
    logs = sdk.get_attendance(ip_address="192.9.224.4", port=5010)
    # logs -> list of AttendanceRecord(user_id=..., timestamp=..., punch=...)
    sdk.disconnect()
"""

import ctypes
import os
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional

CCHEX_RET_RECORD_INFO_TYPE = 1            # from MsgType enum in anviznew.cs
CCHEX_RET_CLINECT_CONNECT_FAIL_TYPE = 200

# Pause after disconnect to let the device's firmware fully release its
# internal session/state table entry before we (or another sync cycle) try
# to reconnect. Observed symptom without this: CONNECT_FAIL mid-poll on the
# very next connection attempt, even though our own disconnect() completed
# cleanly seconds earlier. Tune this up if CONNECT_FAIL persists with short
# scheduler intervals; tune down (or remove) if it turns out unnecessary.
DISCONNECT_SETTLE_SECONDS = 2.0


def _trace(msg: str):
    """
    Writes a timestamped progress marker to stderr only.

    stdout is a strict contract with the parent process (anviz_pull_worker.py
    prints exactly one JSON payload there and nothing else — anything extra
    would break the parent's json.loads()). stderr has no such contract and
    is already captured and logged by _pull_anviz_logs() in
    sync_biometric_logs.py on failure, so these markers show up for free in
    the existing failure log line without any parent-side changes.

    Purpose: when a run hits the outer timeout, these markers let us
    tell, after the fact, exactly which native call the process was stuck
    in -- CCHex_ClientConnect (device never completed the login handshake)
    vs. the CChex_Update polling loop (device logged in but never streamed
    records, or streamed some then stalled) -- instead of just knowing
    "it timed out somewhere in there."
    """
    ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    print(f"[{ts}] {msg}", file=sys.stderr, flush=True)


class AnvizConnectionError(Exception):
    pass


@dataclass
class AttendanceRecord:
    """Shaped to match python-zk's attendance record fields (user_id, timestamp, punch)
    so it can substitute directly for `entry` in sync_bio.py's loop."""
    user_id: str
    timestamp: datetime
    punch: int


class _CCHEX_RET_RECORD_INFO_STRU(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("MachineId", ctypes.c_uint32),
        ("NewRecordFlag", ctypes.c_ubyte),
        ("EmployeeId", ctypes.c_ubyte * 5),
        ("Date", ctypes.c_ubyte * 4),
        ("BackId", ctypes.c_ubyte),
        ("RecordType", ctypes.c_ubyte),
        ("WorkType", ctypes.c_ubyte * 3),
        ("Rsv", ctypes.c_ubyte),
        ("CurIdx", ctypes.c_uint32),
        ("TotalCnt", ctypes.c_uint32),
    ]


def _decode_date(raw4) -> datetime:
    secs = int.from_bytes(bytes(raw4), 'big')
    return datetime(2000, 1, 1) + timedelta(seconds=secs)
    # NOTE: epoch/byte-order assumption -- verify one record against CrossChex
    # Standard's own displayed timestamp before trusting this in production.
    # If off by exactly one day, use datetime(2000, 1, 2) instead.
    # If wildly wrong (years off), swap 'big' for 'little'.


class AnvizSDK:
    """One instance per scanner connection. Not thread-safe across scanners --
    create a separate AnvizSDK() per worker/thread (mirrors how ZK() is created
    fresh per call in sync_bio.py's _sync_one_scanner)."""

    def __init__(self, dll_path: str | None = None):
        if dll_path is None:
            dll_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tc-b_new_sdk.dll")

        dll_dir = os.path.dirname(dll_path)
        if dll_dir:
            os.add_dll_directory(dll_dir)

        _trace(f"loading DLL: {dll_path}")
        self.lib = ctypes.CDLL(dll_path)
        self._declare_signatures()

        _trace("CChex_Init()")
        self.lib.CChex_Init()
        _trace("CChex_Start()")
        self.handle = self.lib.CChex_Start()
        _trace(f"CChex_Start() returned handle={self.handle}")
        self.dev_idx = None

    def _declare_signatures(self):
        lib = self.lib

        lib.CChex_Init.restype = None
        lib.CChex_Start.restype = ctypes.c_void_p

        lib.CCHex_ClientConnect.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
        lib.CCHex_ClientConnect.restype = ctypes.c_int

        lib.CCHex_ClientDisconnect.argtypes = [ctypes.c_void_p, ctypes.c_int]
        lib.CCHex_ClientDisconnect.restype = ctypes.c_int

        lib.CChex_Stop.argtypes = [ctypes.c_void_p]
        lib.CChex_Stop.restype = None

        lib.CChex_DownloadAllRecords.argtypes = [ctypes.c_void_p, ctypes.c_int]
        lib.CChex_DownloadAllRecords.restype = ctypes.c_int

        # Incremental download: only records the device considers "new"
        # (matching the NewRecordFlag field on each record), so we don't
        # have to re-pull the entire device history every cycle.
        lib.CChex_DownloadAllNewRecords.argtypes = [ctypes.c_void_p, ctypes.c_int]
        lib.CChex_DownloadAllNewRecords.restype = ctypes.c_int

        lib.CChex_Update.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_int),
            ctypes.c_void_p,
            ctypes.c_int,
        ]
        lib.CChex_Update.restype = ctypes.c_int

    def connect(self, ip_address: str, port: int = 5010, settle_seconds: float = 3.0):
        """Connects to the device. Raises AnvizConnectionError on failure.

        settle_seconds: pause after connect to let the device's internal login
        handshake complete before requesting a download (some units reject an
        immediate download request right after connect)."""
        ip_bytes = ip_address.encode() if isinstance(ip_address, str) else ip_address

        _trace(f"CCHex_ClientConnect({ip_address}:{port}) -- calling (blocking, no internal timeout)")
        self.dev_idx = self.lib.CCHex_ClientConnect(self.handle, ip_bytes, port)
        _trace(f"CCHex_ClientConnect returned dev_idx={self.dev_idx}")

        if self.dev_idx < 0:
            raise AnvizConnectionError(
                f"CCHex_ClientConnect failed (returned {self.dev_idx}) for {ip_address}:{port}"
            )

        _trace(f"settling {settle_seconds}s post-connect")
        time.sleep(settle_seconds)
        return self.dev_idx

    def get_attendance(self, timeout_seconds: float = 20.0) -> list:
        """Requests and pulls all NEW attendance records (records the device
        hasn't previously delivered), matching python-zk's entry.user_id /
        .timestamp / .punch shape so it drops into sync_bio.py's existing
        loop with minimal changes.

        Raises AnvizConnectionError if the device rejects the session mid-poll
        (message type 200) AFTER records had already started arriving -- this
        usually means another client (e.g. CrossChex Standard) is already
        connected, or a prior session wasn't cleanly closed. If this same
        message type 200 arrives with ZERO records ever received in this
        session, it's treated as "no new records available" instead of an
        error -- this is the observed behavior of CChex_DownloadAllNewRecords
        when there's simply nothing new to send, not a real conflict."""
        if self.dev_idx is None:
            raise RuntimeError("Must call connect() before get_attendance()")

        _trace(f"CChex_DownloadAllNewRecords(dev_idx={self.dev_idx}) -- requesting record download")
        ret = self.lib.CChex_DownloadAllNewRecords(self.handle, self.dev_idx)
        _trace(f"CChex_DownloadAllNewRecords returned {ret}")

        buf_len = 4096
        buf = ctypes.create_string_buffer(buf_len)
        dev_idx_arr = (ctypes.c_int * 1)(self.dev_idx)
        type_arr = (ctypes.c_int * 1)(0)

        raw_records = []
        idle_ticks = 0
        max_idle = int(timeout_seconds / 0.05)

        _trace(
            f"entering CChex_Update poll loop "
            f"(internal idle timeout={timeout_seconds}s, this is separate from "
            f"the outer process-level timeout)"
        )
        poll_iterations = 0
        last_log_iteration = 0

        while True:
            ret = self.lib.CChex_Update(
                self.handle, dev_idx_arr, type_arr, ctypes.cast(buf, ctypes.c_void_p), buf_len
            )
            poll_iterations += 1

            if ret == 0:
                idle_ticks += 1
                if poll_iterations - last_log_iteration >= 40:
                    _trace(
                        f"poll loop idle ({idle_ticks}/{max_idle} idle ticks, "
                        f"{len(raw_records)} record(s) received so far)"
                    )
                    last_log_iteration = poll_iterations
                if idle_ticks > max_idle:
                    _trace(
                        f"poll loop hit internal idle timeout ({timeout_seconds}s) -- "
                        f"device stopped sending anything (login likely succeeded, "
                        f"but no further data arrived); returning "
                        f"{len(raw_records)} record(s) collected so far"
                    )
                    break
                time.sleep(0.05)
                continue

            idle_ticks = 0

            if ret < 0:
                needed = -ret
                _trace(f"buffer too small, growing to {needed} bytes and retrying")
                buf = ctypes.create_string_buffer(needed)
                buf_len = needed
                continue

            if type_arr[0] == CCHEX_RET_CLINECT_CONNECT_FAIL_TYPE:
                if len(raw_records) == 0:
                    _trace(
                        "received CCHEX_RET_CLINECT_CONNECT_FAIL_TYPE (200) with "
                        "0 records received so far -- treating as 'no new records' "
                        "rather than a real session conflict"
                    )
                    break
                _trace(
                    f"received CCHEX_RET_CLINECT_CONNECT_FAIL_TYPE (200) after "
                    f"{len(raw_records)} record(s) already received -- treating as "
                    f"a genuine mid-session rejection"
                )
                raise AnvizConnectionError(
                    "Device rejected the connection mid-session (CONNECT_FAIL). "
                    "Another client may already be connected, or a prior session "
                    "wasn't cleanly closed."
                )

            elif type_arr[0] == CCHEX_RET_RECORD_INFO_TYPE:
                rec = _CCHEX_RET_RECORD_INFO_STRU.from_buffer_copy(
                    buf.raw[:ctypes.sizeof(_CCHEX_RET_RECORD_INFO_STRU)]
                )
                raw_records.append(rec)

                if rec.TotalCnt > 0 and rec.CurIdx + 1 >= rec.TotalCnt:
                    _trace(f"received final record ({rec.CurIdx + 1}/{rec.TotalCnt}) -- download complete")
                    break
            # else: ignore other message types (login/status pushes, etc.)

        _trace(f"get_attendance() returning {len(raw_records)} record(s)")
        return [
            AttendanceRecord(
                user_id=str(int.from_bytes(bytes(rec.EmployeeId), 'big')),
                timestamp=_decode_date(rec.Date),
                punch=rec.RecordType,
            )
            for rec in raw_records
        ]

    def disconnect(self):
        if self.dev_idx is None:
            return  # already disconnected -- avoid double-free into the native handle

        try:
            self.lib.CCHex_ClientDisconnect(self.handle, self.dev_idx)
        except Exception:
            pass
        try:
            self.lib.CChex_Stop(self.handle)
        except Exception:
            pass
        self.dev_idx = None

        _trace(f"settling {DISCONNECT_SETTLE_SECONDS}s post-disconnect")
        time.sleep(DISCONNECT_SETTLE_SECONDS)
        _trace("disconnect() complete")