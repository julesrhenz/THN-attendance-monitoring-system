"""
diagnose_anviz_dll.py
----------------------
Run this standalone (same folder as tc-b_new_sdk.dll) to isolate why
CChex_Start() is returning a null handle. It checks, in order:

1. Whether your Python interpreter is 32-bit or 64-bit.
2. Whether tc-b_new_sdk.dll is actually a 32-bit or 64-bit PE file
   (reads the PE header directly -- no dependency on the DLL loading
   correctly first).
3. Whether ctypes can load it at all.
4. Whether CChex_Version() returns something sane (this call takes no
   handle, so it's a good baseline test independent of Start()).
5. Whether CChex_Start() succeeds, and if not, whether
   CChex_Start_With_Param(0, 0) does (some SDK builds behave differently
   between these two entry points).

Run it with:
    python diagnose_anviz_dll.py [path\\to\\tc-b_new_sdk.dll]
"""

import ctypes
import ctypes.util
import os
import platform
import struct
import sys


def check_python_bitness():
    bits = struct.calcsize("P") * 8
    print(f"Python interpreter: {bits}-bit  (platform.architecture() = {platform.architecture()})")
    return bits


def check_dll_bitness(dll_path):
    with open(dll_path, "rb") as f:
        data = f.read(1024)
    pe_offset = struct.unpack("<I", data[0x3C:0x40])[0]
    machine = struct.unpack("<H", data[pe_offset + 4:pe_offset + 6])[0]
    machine_map = {
        0x014C: ("I386", 32),
        0x8664: ("AMD64", 64),
        0x01C0: ("ARM", 32),
        0xAA64: ("ARM64", 64),
    }
    name, bits = machine_map.get(machine, (hex(machine), None))
    print(f"DLL machine type: {name} ({bits}-bit)" if bits else f"DLL machine type: unknown ({name})")
    return bits


def list_dependencies(dll_path):
    """Best-effort listing of the DLL's declared dependencies, using
    pefile if available. Not required for the fix below, just helpful
    for pinpointing exactly which companion DLL is missing."""
    try:
        import pefile
    except ImportError:
        print("(Optional: `pip install pefile` to see exactly which "
              "dependency DLL is missing -- skipping that for now.)\n")
        return

    try:
        pe = pefile.PE(dll_path)
        pe.parse_data_directories()
        dll_dir = os.path.dirname(os.path.abspath(dll_path))
        print("Declared dependencies:")
        for entry in pe.DIRECTORY_ENTRY_IMPORT:
            dep_name = entry.dll.decode(errors="ignore")
            local_path = os.path.join(dll_dir, dep_name)
            found_locally = os.path.exists(local_path)
            found_system = ctypes.util.find_library(dep_name.rsplit(".", 1)[0]) is not None
            status = "OK (next to DLL)" if found_locally else (
                "OK (on system path)" if found_system else "*** MISSING ***"
            )
            print(f"  {dep_name:30s} {status}")
        print()
    except Exception as exc:
        print(f"(Could not parse import table: {exc})\n")


def load_dll(dll_path):
    """Adds the DLL's own directory to the search path before loading --
    required on Python 3.8+ for the DLL to find sibling dependency DLLs,
    which is the #1 cause of 'module not found' errors that only mention
    the DLL you asked for."""
    dll_dir = os.path.dirname(os.path.abspath(dll_path))
    if dll_dir and hasattr(os, "add_dll_directory"):
        os.add_dll_directory(dll_dir)
    try:
        return ctypes.CDLL(dll_path, winmode=0)
    except TypeError:
        # winmode kwarg not supported on this platform/Python -- fall back
        return ctypes.CDLL(dll_path)


def main():
    dll_path = sys.argv[1] if len(sys.argv) > 1 else "tc-b_new_sdk.dll"
    print(f"Checking: {dll_path}\n")

    py_bits = check_python_bitness()
    dll_bits = check_dll_bitness(dll_path)

    if dll_bits and py_bits != dll_bits:
        print(
            f"\n*** MISMATCH: Python is {py_bits}-bit but the DLL is {dll_bits}-bit. ***\n"
            f"This alone can cause exactly the symptom you saw (load 'succeeds' in some "
            f"environments but internal calls misbehave / return null).\n"
            f"Fix: install a {dll_bits}-bit Python and rerun this script with that "
            f"interpreter.\n"
        )
    else:
        print("Bitness matches (or DLL type unknown) -- moving on to load test.\n")

    list_dependencies(dll_path)

    print("Attempting ctypes.CDLL load (with DLL directory added to search path)...")
    try:
        dll = load_dll(dll_path)
    except OSError as exc:
        print(f"FAILED to load DLL: {exc}")
        print("If this still fails after adding the DLL's own directory to the "
              "search path, a genuinely missing companion DLL (see the "
              "dependency list above, or install matching VC++ Redistributable) "
              "is the most likely cause.")
        return
    print("Loaded OK.\n")

    dll.CChex_Version.restype = ctypes.c_uint32
    dll.CChex_Version.argtypes = []
    try:
        version = dll.CChex_Version()
        print(f"CChex_Version() = {version}  (sanity check passed)\n")
    except Exception as exc:
        print(f"CChex_Version() raised: {exc}")
        print("If even this fails, the DLL is not correctly callable in this "
              "process -- almost certainly an architecture/ABI mismatch.\n")
        return

    dll.CChex_Init.restype = None
    dll.CChex_Init.argtypes = []
    dll.CChex_Init()
    print("CChex_Init() called.\n")

    dll.CChex_Start.restype = ctypes.c_void_p
    dll.CChex_Start.argtypes = []
    handle = dll.CChex_Start()
    print(f"CChex_Start() -> {handle}")

    if not handle:
        print("Null handle from CChex_Start(). Trying CChex_Start_With_Param(0, 0)...")
        dll.CChex_Start_With_Param.restype = ctypes.c_void_p
        dll.CChex_Start_With_Param.argtypes = [ctypes.c_uint32, ctypes.c_uint32]
        handle2 = dll.CChex_Start_With_Param(0, 0)
        print(f"CChex_Start_With_Param(0, 0) -> {handle2}")

        if not handle2:
            print(
                "\nBoth start functions returned null. This means CChex_Version/"
                "CChex_Init succeeded but the SDK's internal listener could not "
                "start. Likely causes, roughly in order of likelihood:\n"
                "  1. Another process (a previous crashed run of this script, or "
                "the original C# app) still has the SDK's internal port bound. "
                "Reboot or find/kill the other process and retry.\n"
                "  2. The process needs Administrator privileges to open a "
                "listening socket in your environment -- try 'Run as "
                "Administrator'.\n"
                "  3. A firewall or endpoint security tool is silently blocking "
                "the socket bind.\n"
                "  4. A missing runtime dependency (Visual C++ Redistributable "
                "matching the DLL's bitness) that doesn't surface as a load "
                "error but breaks internal initialization.\n"
            )
        else:
            print(
                "\nCChex_Start_With_Param(0, 0) worked where CChex_Start() did "
                "not. Update anviz_ep300.py's start() to call "
                "CChex_Start_With_Param(0, 0) instead of CChex_Start()."
            )
    else:
        print("\nCChex_Start() succeeded -- the null-handle issue you saw "
              "before may have been transient (e.g. a port conflict that's "
              "now cleared). Try your real script again.")


if __name__ == "__main__":
    main()